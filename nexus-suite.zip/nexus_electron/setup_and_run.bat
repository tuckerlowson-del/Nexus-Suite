@echo off
title NEXUS SUITE — Setup and Dev
color 0A

echo.
echo  ============================================
echo   NEXUS SUITE — Electron Setup
echo   Built by TuckerLawson
echo  ============================================
echo.

:: Check Node.js
node --version >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    echo [!] Node.js not found — downloading...
    powershell -Command "Invoke-WebRequest -Uri 'https://nodejs.org/dist/v20.11.1/node-v20.11.1-x64.msi' -OutFile 'node_installer.msi'"
    msiexec /i node_installer.msi /quiet /norestart
    del node_installer.msi >nul 2>&1
    echo [OK] Node.js installed — please restart CMD and run this script again
    pause
    exit /b
)
echo [OK] Node.js found

:: Check Python
python --version >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    echo [!] Python not found — downloading...
    powershell -Command "Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe' -OutFile 'python_installer.exe'"
    python_installer.exe /quiet InstallAllUsers=1 PrependPath=1 Include_test=0
    del python_installer.exe >nul 2>&1
    echo [OK] Python installed
)
echo [OK] Python found

:: Install Python deps
echo.
echo [1/3] Installing Python AI libraries...
python -m pip install anthropic openai --quiet
echo [OK] Python deps installed

:: Install Node deps
echo.
echo [2/3] Installing Node.js dependencies...
npm install
echo [OK] Node deps installed

:: Run in dev mode
echo.
echo [3/3] Starting Nexus Suite in dev mode...
echo.
echo  Open http://localhost:5173 if the window doesn't open
echo  Press Ctrl+C to stop
echo.
npm run dev
