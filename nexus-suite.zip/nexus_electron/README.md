# ⬡ NEXUS SUITE — Electron Edition
**Built by TuckerLawson**

FiveM AI Development Platform — Electron + React + Python

---

## 🚀 Quick Start

### Prerequisites
- **Node.js 20+** → https://nodejs.org/downloads
- **Python 3.11+** → https://python.org/downloads *(check Add to PATH)*
- **Git** → https://git-scm.com *(optional)*

### Run in Dev Mode
```bash
# 1. Double-click setup_and_run.bat
# It installs everything and launches the app automatically
```

Or manually:
```bash
npm install
python -m pip install anthropic openai
npm run dev
```

### Build Windows Installer
```bash
# Double-click build_installer.bat
# Your installer appears in dist-installer/
```

Or manually:
```bash
npm run dist
```

---

## 📁 Project Structure

```
nexus_electron/
│
├── src/
│   ├── main/
│   │   ├── main.js          ← Electron main process
│   │   └── preload.js       ← Secure IPC bridge
│   │
│   └── renderer/            ← React frontend
│       ├── App.jsx           ← Root component + routing
│       ├── main.jsx          ← React entry point
│       ├── store/            ← Zustand global state
│       ├── components/       ← Shared UI components
│       │   ├── TitleBar.jsx  ← Custom frameless titlebar
│       │   └── Sidebar.jsx   ← Navigation sidebar
│       ├── pages/
│       │   ├── LoginPage.jsx       ← Google OAuth
│       │   ├── DashboardPage.jsx   ← Home/stats
│       │   ├── AICorePage.jsx      ← Main AI pipeline
│       │   ├── ServerPanelPage.jsx ← HTN Panel clone
│       │   ├── FilesPage.jsx       ← Monaco file editor
│       │   └── OtherPages.jsx      ← Library/History/WebTools/Settings
│       └── styles/
│           └── globals.css   ← Tailwind + custom CSS
│
├── python/
│   └── pipeline.py          ← AI pipeline backend (IPC)
│
├── assets/
│   └── icon.png             ← App icon (create your own)
│
├── scripts/
│   └── installer.nsh        ← NSIS installer customization
│
├── package.json             ← Node dependencies + build config
├── vite.config.js           ← Vite bundler config
├── tailwind.config.js       ← Tailwind design system
├── postcss.config.js        ← PostCSS config
├── setup_and_run.bat        ← One-click dev setup
└── build_installer.bat      ← One-click installer build
```

---

## 🔐 Google OAuth

Your Google OAuth credentials are already wired in:
- **Client ID:** `5734757119-8e4egl8qmu4ojpo1nunj3nnscgk28vva.apps.googleusercontent.com`
- **Client Secret:** stored in `src/main/main.js`

The auth flow opens the real Google sign-in popup in the user's browser,
then catches the callback on localhost:42813 automatically.

---

## 🔑 API Keys (per user, encrypted)

Each Google account gets their own encrypted key storage at:
```
%APPDATA%\Nexus Suite\accounts\[google_id]\keys.enc
```

Keys are AES-256 encrypted. Users add them in Settings.

---

## 🤖 AI Agents

| Agent | API | Role |
|---|---|---|
| Claude | Anthropic | Planner, Reviewer, Security |
| GPT-4o | OpenAI | Lead Coder, Debugger |
| Grok | xAI | Bug Hunter |
| Gemini | Google | UI/NUI Designer |
| Perplexity | Perplexity | QA Tester |
| Nexus AI | Claude (custom) | FiveM Validator |

Minimum needed: **Claude + GPT-4o**

---

## 📦 What the Installer Creates

```
C:\Program Files\Nexus Suite\
├── NexusSuite.exe
└── resources\...

Start Menu → Nexus Suite → Nexus Suite.lnk
Desktop → Nexus Suite.lnk
Windows Search → "Nexus Suite"
Add/Remove Programs → Nexus Suite v1.0
```

---

## 💰 Cost

```
App:          FREE
Google OAuth: FREE
API keys:     ~$5-20/month depending on usage
```

---

## 🎨 UI Stack

- **Electron 28** — desktop shell, frameless window
- **React 18 + Vite** — fast frontend
- **Tailwind CSS** — utility styling
- **Framer Motion** — smooth animations
- **Monaco Editor** — VS Code-powered file editor
- **Zustand** — global state
- **Inter + JetBrains Mono** — typography
