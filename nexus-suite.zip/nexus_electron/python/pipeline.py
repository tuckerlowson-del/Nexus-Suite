#!/usr/bin/env python3
"""
Nexus Suite — Python AI Pipeline Backend
Communicates with Electron via stdin/stdout JSON lines
Built by TuckerLawson
"""
import sys
import json
import os
import re
import time
import threading
import shutil
from pathlib import Path
from datetime import datetime

try:
    import anthropic
    HAS_ANTHROPIC = True
except ImportError:
    HAS_ANTHROPIC = False

try:
    from openai import OpenAI
    HAS_OPENAI = True
except ImportError:
    HAS_OPENAI = False

import urllib.request
import urllib.error

# ── Output to Electron ────────────────────────────────
def send(agent, text):
    msg = json.dumps({"agent": agent, "text": text})
    print(msg, flush=True)

def send_phase(phase, num):
    msg = json.dumps({"phase": phase, "phase_num": num})
    print(msg, flush=True)

def send_done(files, final):
    msg = json.dumps({"done": True, "files": files, "final": final})
    print(msg, flush=True)

def send_error(text):
    msg = json.dumps({"agent": "error", "text": f"ERROR: {text}\n"})
    print(msg, flush=True)

def log(text):
    send("sys", f"{text}\n")

# ── System Prompts ────────────────────────────────────
BASE = """You are a senior FiveM server developer with 10+ years experience.
Specializing in Lua, JavaScript NUI, ESX, QB-Core, Qbox, ox_lib, MySQL/oxmysql,
server.cfg, resource manifests, NUI HTML/CSS/JS, all FiveM natives.
RULES: Raw code only. No markdown fences. Complete files. No placeholders. No TODOs.
Separate multiple files with ===filename=== markers."""

PLAN_SYS  = BASE + "\nYou are PM. Output: FRAMEWORK/FILES/DATABASE/CODE_TASK/UI_TASK/QA_TASK/SUMMARY"
CODE_SYS  = BASE + "\nLead Coder. Write complete FiveM code. Use ===filename=== separators."
DEBUG_SYS = BASE + "\nDebug Specialist. List BUGS_FOUND: then FIXED_CODE: with complete corrected code."
UI_SYS    = BASE + "\nNUI Specialist. Dark glassmorphism. Complete PostMessage/SetNuiFocus. Raw HTML only."
QA_SYS    = BASE + "\nQA Engineer. CHECK: [name] — PASS/FAIL — [reason] for each item."
SEC_SYS   = BASE + "\nSecurity Auditor. ISSUE: [desc] — LINE: [n] per issue. Or: SECURITY: CLEAN"

# ── AI Engine ─────────────────────────────────────────
class AI:
    def __init__(self, keys):
        self.keys  = keys
        self.cl    = None
        self.oai   = None
        self.grok  = None
        self.pplx  = None
        self._init()

    def _init(self):
        if HAS_ANTHROPIC and self.keys.get("claude","").strip():
            try: self.cl = anthropic.Anthropic(api_key=self.keys["claude"])
            except: pass
        if HAS_OPENAI:
            if self.keys.get("openai","").strip():
                try: self.oai = OpenAI(api_key=self.keys["openai"])
                except: pass
            if self.keys.get("grok","").strip():
                try: self.grok = OpenAI(api_key=self.keys["grok"], base_url="https://api.x.ai/v1")
                except: pass
            if self.keys.get("perplexity","").strip():
                try: self.pplx = OpenAI(api_key=self.keys["perplexity"], base_url="https://api.perplexity.ai")
                except: pass

    def _is_real(self, text):
        if not text or len(text.strip()) < 30: return False
        bad = ["not configured","not set","api key","error:","[claude","[gpt","[grok","add key"]
        return not any(b in text.lower()[:100] for b in bad)

    def claude(self, prompt, system=BASE, retry=2):
        if not self.cl: return None, "Claude not configured"
        for i in range(retry):
            try:
                r = self.cl.messages.create(
                    model="claude-sonnet-4-6", max_tokens=4096,
                    system=system, messages=[{"role":"user","content":prompt}]
                )
                result = r.content[0].text
                if self._is_real(result): return result, None
            except Exception as e:
                if i == retry-1: return None, str(e)
                time.sleep(2)
        return None, "Invalid response"

    def gpt(self, prompt, system=BASE, retry=2):
        if not self.oai: return None, "GPT-4o not configured"
        for i in range(retry):
            try:
                r = self.oai.chat.completions.create(
                    model="gpt-4o", max_tokens=4096,
                    messages=[{"role":"system","content":system},{"role":"user","content":prompt}]
                )
                result = r.choices[0].message.content
                if self._is_real(result): return result, None
            except Exception as e:
                if i == retry-1: return None, str(e)
                time.sleep(2)
        return None, "Invalid response"

    def grok_(self, prompt, system=BASE, retry=2):
        if not self.grok: return None, "Grok not configured"
        for i in range(retry):
            try:
                r = self.grok.chat.completions.create(
                    model="grok-3", max_tokens=4096,
                    messages=[{"role":"system","content":system},{"role":"user","content":prompt}]
                )
                result = r.choices[0].message.content
                if self._is_real(result): return result, None
            except Exception as e:
                if i == retry-1: return None, str(e)
                time.sleep(2)
        return None, "Invalid response"

    def gemini(self, prompt, retry=2):
        key = self.keys.get("gemini","").strip()
        if not key: return None, "Gemini not configured"
        for i in range(retry):
            try:
                url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro:generateContent?key={key}"
                body = json.dumps({"contents":[{"parts":[{"text":BASE+"\n\n"+prompt}]}],"generationConfig":{"maxOutputTokens":4096,"temperature":0.3}}).encode()
                req  = urllib.request.Request(url, data=body, headers={"Content-Type":"application/json"})
                with urllib.request.urlopen(req, timeout=60) as r:
                    data = json.loads(r.read())
                result = data["candidates"][0]["content"]["parts"][0]["text"]
                if self._is_real(result): return result, None
            except Exception as e:
                if i == retry-1: return None, str(e)
                time.sleep(2)
        return None, "Invalid response"

    def perplexity(self, prompt, system=BASE, retry=2):
        if not self.pplx: return None, "Perplexity not configured"
        for i in range(retry):
            try:
                r = self.pplx.chat.completions.create(
                    model="llama-3.1-sonar-large-128k-online", max_tokens=4096,
                    messages=[{"role":"system","content":system},{"role":"user","content":prompt}]
                )
                result = r.choices[0].message.content
                if self._is_real(result): return result, None
            except Exception as e:
                if i == retry-1: return None, str(e)
                time.sleep(2)
        return None, "Invalid response"

    def nexus(self, prompt):
        return self.claude(prompt, system=PLAN_SYS.replace("PM","FiveM Validator"))

# ── File Parser ───────────────────────────────────────
def parse_files(code, nui=""):
    files = {}
    if re.search(r"===[\w./\\-]+===", code):
        parts = re.split(r"===([\w./\\-]+)===", code)
        i = 1
        while i < len(parts)-1:
            fname   = parts[i].strip()
            content = parts[i+1].strip()
            if fname and content and len(content) > 10:
                files[fname] = content
            i += 2

    if not files:
        for pat, name, default in [
            (r"fx_version\s+'[^']+'\s+game\s+'[^']+'.{50,}?(?=\n\n--|\Z)", "fxmanifest.lua", "fx_version 'cerulean'\ngame 'gta5'\n"),
            (r"(?:RegisterServerEvent|AddEventHandler|MySQL\.query).{100,}?(?=\n\n--\s*client|\Z)", "server.lua", "-- server.lua\n"),
            (r"(?:RegisterNetEvent|Citizen\.CreateThread|TriggerEvent).{100,}?(?=\n\n--\s*config|\Z)",  "client.lua", "-- client.lua\n"),
            (r"Config\s*=\s*\{.{20,}?\}",  "config.lua",  "Config = {}\n"),
        ]:
            m = re.search(pat, code, re.DOTALL | re.IGNORECASE)
            files[name] = m.group(0).strip() if m else default

    if nui and len(nui.strip()) > 100:
        nui_clean = re.sub(r"```html\n?|```\n?", "", nui).strip()
        files["html/index.html"] = nui_clean

    return {k: v for k, v in files.items() if v and len(v.strip()) > 5}

def write_files(files, resource_name, resources_path):
    if not resources_path or not os.path.exists(resources_path):
        return None, "Resources path not set"
    nexus_dir = Path(resources_path) / "[nexus]"
    nexus_dir.mkdir(exist_ok=True)
    res_dir = nexus_dir / resource_name
    res_dir.mkdir(parents=True, exist_ok=True)

    written = []
    for fname, content in files.items():
        target = res_dir / fname
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        written.append(fname)
        send("nexus", f"  ✅ Written: {fname} ({len(content)} chars)\n")

    log_content = f"# NEXUS CHANGELOG\nBuilt: {datetime.now()}\nFiles: {len(written)}\n---\n" + "\n".join(f"✅ {f}" for f in written)
    (res_dir / "NEXUS_CHANGELOG.md").write_text(log_content)
    return str(res_dir), None

# ── Pipeline ──────────────────────────────────────────
cancelled = False

def run_pipeline(task, keys, config, context):
    global cancelled
    cancelled = False

    ai  = AI(keys)
    fw  = context.get("framework", "QBCore")
    rp  = config.get("resourcesPath", "")
    R   = {}

    def ok(): return not cancelled
    def log_agent(agent, text): send(agent, text)
    def phase(name, num): send_phase(name, num)

    # Phase 1: Scan
    phase("Scanning Server", 1)
    log("🔍 Server scan complete\n")
    log(f"📦 Framework: {fw} | Resources: {context.get('resource_count', 0)}\n")
    if not ok(): return

    # Phase 2: Plan
    phase("Planning", 2)
    log_agent("claude", "📋 Claude planning task breakdown...\n")
    plan, err = ai.claude(f"Plan this FiveM task:\nFRAMEWORK: {fw}\nTASK: {task}", PLAN_SYS)
    if not plan:
        send_error(f"Planning failed: {err}")
        return
    R["plan"] = plan
    log_agent("claude", f"✅ Plan complete\n{plan[:300]}\n...\n")
    if not ok(): return

    # Phase 3: Code
    phase("Writing Code", 3)
    code_prompt = f"Write complete FiveM code.\nFRAMEWORK: {fw}\nTASK: {task}\nPLAN: {R['plan']}\nWrite fxmanifest.lua, server.lua, client.lua, config.lua. Use ===filename=== separators."

    log_agent("gpt", "💻 GPT-4o writing first draft...\n")
    gpt_code, err = ai.gpt(code_prompt, CODE_SYS)
    if not gpt_code:
        log_agent("gpt", f"⚠️ GPT unavailable ({err}) — Claude writing code\n")
        gpt_code, err = ai.claude(code_prompt, CODE_SYS)
        if not gpt_code:
            send_error(f"Code writing failed: {err}")
            return
    log_agent("gpt", f"✅ GPT draft complete — {len(gpt_code)} chars\n")
    if not ok(): return

    log_agent("claude", "🔍 Claude reviewing and improving...\n")
    cl_code, err = ai.claude(f"Review and improve this FiveM {fw} code:\n{gpt_code}\nTask: {task}\nOutput complete improved code.", CODE_SYS)
    R["code"] = cl_code or gpt_code
    log_agent("claude", f"✅ Claude review done\n")
    if not ok(): return

    log_agent("nexus_ai", "⬡ Nexus AI FiveM validation...\n")
    val, _ = ai.nexus(f"Validate {fw} code:\n{R['code'][:2000]}\nFix framework-specific issues.")
    if val and ai._is_real(val): R["code"] = val
    log_agent("nexus_ai", "✅ Nexus AI validation done\n")
    if not ok(): return

    # Phase 4: Debug
    phase("Debugging", 4)
    debug_prompt = f"Find and fix ALL bugs:\n{R['code']}"

    log_agent("grok", "🐛 Grok fast bug scan...\n")
    grok_r, _ = ai.grok_(debug_prompt, DEBUG_SYS)
    if grok_r:
        m = re.search(r"FIXED_CODE:\s*\n([\s\S]+)", grok_r)
        if m: R["code"] = m.group(1).strip()
        log_agent("grok", f"✅ Grok done\n{grok_r[:200]}\n")
    else:
        log_agent("grok", "⚠️ Grok skipped (no key)\n")
    if not ok(): return

    log_agent("claude", "🧠 Claude deep logic review...\n")
    cl_dbg, _ = ai.claude(f"Deep review for logic errors, nil refs, missing callbacks:\n{R['code'][:2000]}\nOutput FIXED_CODE: with corrections.", DEBUG_SYS)
    if cl_dbg:
        m = re.search(r"FIXED_CODE:\s*\n([\s\S]+)", cl_dbg)
        if m: R["code"] = m.group(1).strip()
        log_agent("claude", "✅ Claude deep fix applied\n")
    if not ok(): return

    log_agent("gpt", "🔎 GPT-4o final syntax pass...\n")
    gpt_final, _ = ai.gpt(f"Final syntax check — fix brackets, strings, functions:\n{R['code'][:2000]}\nOutput ONLY complete corrected code.", CODE_SYS)
    if gpt_final and ai._is_real(gpt_final): R["code"] = gpt_final
    log_agent("gpt", "✅ All debug done\n")
    if not ok(): return

    # Phase 5: UI/NUI
    phase("Building UI/NUI", 5)
    ui_prompt = f"Build complete FiveM NUI interface.\nTASK: {task}\nFRAMEWORK: {fw}\nDark glassmorphism. All PostMessage handlers. One complete index.html."

    log_agent("claude", "🎨 Claude designing NUI structure...\n")
    nui_plan, _ = ai.claude(ui_prompt, UI_SYS)
    log_agent("claude", "✅ NUI structure done\n")
    if not ok(): return

    log_agent("gemini", "🖼️ Gemini building HTML+CSS...\n")
    gem_nui, err = ai.gemini(f"Build complete HTML+CSS for FiveM NUI:\nTask: {task}\nLayout: {nui_plan[:400] if nui_plan else 'Standard menu'}\nDark glass style. Output index.html only.")
    R["nui"] = gem_nui or nui_plan or ""
    log_agent("gemini", "✅ Gemini HTML done\n" if gem_nui else f"⚠️ Gemini skipped ({err})\n")
    if not ok(): return

    log_agent("gpt", "⚡ GPT-4o adding JS+PostMessage...\n")
    gpt_nui, _ = ai.gpt(f"Add complete JS PostMessage handlers for FiveM NUI:\nFramework: {fw}\nHTML: {R['nui'][:600]}\nOutput complete index.html.", UI_SYS)
    if gpt_nui and ai._is_real(gpt_nui): R["nui"] = gpt_nui
    log_agent("gpt", "✅ JS done\n")
    if not ok(): return

    log_agent("nexus_ai", "⬡ Nexus AI NUI validation...\n")
    nui_val, _ = ai.nexus(f"Validate FiveM NUI for {fw}:\n{R['nui'][:800]}\nFix SetNuiFocus/SendNUIMessage issues.")
    if nui_val and ai._is_real(nui_val): R["nui"] = nui_val
    log_agent("nexus_ai", "✅ NUI validated\n")
    if not ok(): return

    # Phase 6: QA
    phase("QA Testing", 6)
    log_agent("perp", "🔍 Perplexity checking live FiveM docs...\n")
    pqa, _ = ai.perplexity(f"QA check against current {fw} FiveM docs:\n{R['code'][:1000]}", QA_SYS)
    qa_failed = pqa and "FAIL" in pqa
    log_agent("perp", f"{'⚠️ Issues found' if qa_failed else '✅ QA passed'}\n")
    if not ok(): return

    log_agent("claude", "🛡️ Claude security+logic QA...\n")
    cl_qa, _ = ai.claude(f"QA audit — logic, security, edge cases:\n{R['code'][:1500]}", QA_SYS)
    if cl_qa and "FAIL" in cl_qa: qa_failed = True
    log_agent("claude", "✅ Logic QA done\n")
    if not ok(): return

    log_agent("gemini", "🖥️ Gemini NUI render check...\n")
    gem_qa, _ = ai.gemini(f"QA check NUI render+PostMessage flow:\n{R['nui'][:600]}")
    log_agent("gemini", "✅ NUI QA done\n")

    if qa_failed:
        log_agent("nexus", "⚠️ QA issues — auto-fixing...\n")
        fixed_qa, _ = ai.claude(f"Fix QA issues:\n{cl_qa or pqa}\nCode:\n{R['code'][:2000]}", CODE_SYS)
        if fixed_qa: R["code"] = fixed_qa
        log_agent("nexus", "✅ QA fixes applied\n")
    if not ok(): return

    # Phase 7: Security
    phase("Security Audit", 7)
    log_agent("claude", "🔒 Security audit...\n")
    sec, _ = ai.claude(f"Security audit:\n{R['code'][:2000]}", SEC_SYS)
    sec_clean = not sec or "SECURITY: CLEAN" in (sec or "").upper() or "ISSUE:" not in (sec or "").upper()
    if not sec_clean:
        log_agent("claude", f"🔒 Issues found — patching...\n")
        patched, _ = ai.claude(f"Fix security:\n{sec}\nCode:\n{R['code'][:2000]}\nOutput complete secured code.", CODE_SYS)
        if patched: R["code"] = patched
        log_agent("claude", "✅ Security patched\n")
    else:
        log_agent("claude", "✅ Security clean\n")
    if not ok(): return

    # Phase 8: Deploy
    phase("Writing Files to Server", 8)
    log_agent("nexus", "📦 Parsing output into files...\n")
    files = parse_files(R["code"], R.get("nui",""))
    log_agent("nexus", f"📄 Files: {list(files.keys())}\n")

    slug = re.sub(r"[^a-z0-9]+","-",task.lower().strip())[:30].strip("-") or "nexus-resource"
    written_path, write_err = write_files(files, slug, rp)

    if write_err and not written_path:
        log_agent("nexus", f"⚠️ Deploy skipped: {write_err}\n")
        log_agent("nexus", "💡 Set Resources Path in Settings to enable auto-deploy\n")
    else:
        log_agent("nexus", f"✅ Deployed to: {written_path}\n")

    # Done
    phase("Complete", 9)
    final = f"""╔═══════════════════════════════════════╗
║     NEXUS SUITE — BUILD COMPLETE      ║
╚═══════════════════════════════════════╝

Task: {task}
Framework: {fw}
Files: {len(files)}
QA: {'⚠️ Issues fixed' if qa_failed else '✅ Passed'}
Security: {'✅ Clean' if sec_clean else '⚠️ Patched'}
Deploy: {'✅ ' + str(written_path) if written_path else '⚠️ Manual deploy needed'}
Built: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

FILES WRITTEN:
{chr(10).join(f'  ✅ {k} ({len(v)} chars)' for k,v in files.items())}
"""
    send_done(files, final)

# ── Main IPC Loop ─────────────────────────────────────
def main():
    global cancelled

    for line in sys.stdin:
        line = line.strip()
        if not line: continue
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            continue

        msg_type = msg.get("type","")

        if msg_type == "run":
            cancelled = False
            t = threading.Thread(
                target=run_pipeline,
                args=(msg["task"], msg["keys"], msg["config"], msg.get("context",{})),
                daemon=True
            )
            t.start()

        elif msg_type == "cancel":
            cancelled = True
            send("nexus","⏹ Pipeline cancelled\n")

if __name__ == "__main__":
    main()
