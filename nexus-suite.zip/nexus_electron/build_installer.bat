@echo off
title NEXUS SUITE — Build Installer
color 0B

echo.
echo  ============================================
echo   NEXUS SUITE — Building Windows Installer
echo   Built by TuckerLawson
echo  ============================================
echo.

echo [1/4] Checking dependencies...
node --version >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Node.js not found. Run setup_and_run.bat first.
    pause
    exit /b 1
)
echo [OK] Node.js ready

echo.
echo [2/4] Building React frontend...
npm run build
IF %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Frontend build failed.
    pause
    exit /b 1
)
echo [OK] Frontend built

echo.
echo [3/4] Packaging Electron app + installer...
npm run dist
IF %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Packaging failed.
    pause
    exit /b 1
)
echo [OK] Installer built

echo.
echo  ============================================
echo   BUILD COMPLETE!
echo.
echo   Your installer is in:
echo   dist-installer\NexusSuite Setup 1.0.0.exe
echo.
echo   It will:
echo   - Install to C:\Program Files\Nexus Suite\
echo   - Add to Windows Start Menu
echo   - Create Desktop shortcut
echo   - Register in Add/Remove Programs
echo   - Show in Windows Search instantly
echo  ============================================
echo.
pause
