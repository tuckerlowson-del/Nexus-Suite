/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/renderer/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        nexus: {
          bg:      '#060610',
          bg2:     '#0a0a18',
          card:    '#0d0d1f',
          card2:   '#111128',
          card3:   '#161635',
          border:  '#1e1e3f',
          border2: '#2a2a55',
          accent:  '#7c3aed',
          accent2: '#06b6d4',
          purple:  '#a78bfa',
          cyan:    '#22d3ee',
          green:   '#10b981',
          red:     '#f43f5e',
          yellow:  '#f59e0b',
          text:    '#f1f5f9',
          muted:   '#94a3b8',
          faint:   '#475569',
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'Fira Code', 'monospace'],
      },
      backdropBlur: {
        xs: '2px',
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'glow': 'glow 2s ease-in-out infinite alternate',
        'slide-in': 'slideIn 0.3s ease-out',
        'fade-in': 'fadeIn 0.4s ease-out',
        'spin-slow': 'spin 3s linear infinite',
      },
      keyframes: {
        glow: {
          '0%': { boxShadow: '0 0 5px #7c3aed44' },
          '100%': { boxShadow: '0 0 20px #7c3aed88, 0 0 40px #7c3aed33' },
        },
        slideIn: {
          '0%': { transform: 'translateX(-10px)', opacity: 0 },
          '100%': { transform: 'translateX(0)', opacity: 1 },
        },
        fadeIn: {
          '0%': { opacity: 0, transform: 'translateY(8px)' },
          '100%': { opacity: 1, transform: 'translateY(0)' },
        },
      },
      boxShadow: {
        'nexus': '0 0 30px rgba(124,58,237,0.15)',
        'nexus-lg': '0 0 60px rgba(124,58,237,0.25)',
        'card': '0 4px 24px rgba(0,0,0,0.4)',
        'card-hover': '0 8px 40px rgba(0,0,0,0.6)',
      },
    },
  },
  plugins: [],
}
