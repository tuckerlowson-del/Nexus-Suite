#!/usr/bin/env python3
"""
Generate a simple placeholder icon for Nexus Suite
Run this once before building the installer
"""
try:
    from PIL import Image, ImageDraw, ImageFont
    HAS_PIL = True
except ImportError:
    HAS_PIL = False
    print("Pillow not installed — using basic method")
    print("Run: pip install Pillow")

import os

def make_icon():
    os.makedirs("assets", exist_ok=True)

    if HAS_PIL:
        # Create a 256x256 icon
        img = Image.new("RGBA", (256, 256), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        # Background circle
        draw.ellipse([8, 8, 248, 248], fill=(124, 58, 237, 255))

        # Inner glow
        draw.ellipse([20, 20, 236, 236], fill=(109, 40, 217, 255))

        # Hexagon symbol (simplified as text)
        try:
            font = ImageFont.truetype("arial.ttf", 120)
        except:
            font = ImageFont.load_default()

        draw.text((128, 128), "⬡", fill=(255, 255, 255, 255),
                  font=font, anchor="mm")

        img.save("assets/icon.png", "PNG")

        # Also save as ico for Windows
        ico_sizes = [(16,16),(32,32),(48,48),(64,64),(128,128),(256,256)]
        icons = [img.resize(s, Image.LANCZOS) for s in ico_sizes]
        icons[0].save("assets/icon.ico", format="ICO",
                      sizes=ico_sizes, append_images=icons[1:])

        print("✅ Icons created: assets/icon.png and assets/icon.ico")
    else:
        # Create minimal PNG (1x1 purple pixel upscaled)
        with open("assets/icon.png", "wb") as f:
            # Minimal valid PNG file
            import struct, zlib
            def png_chunk(name, data):
                c = struct.pack(">I", len(data)) + name + data
                return c + struct.pack(">I", zlib.crc32(name + data) & 0xffffffff)

            w, h = 64, 64
            raw = b""
            for y in range(h):
                raw += b"\x00"
                for x in range(w):
                    # Purple pixel
                    raw += bytes([124, 58, 237, 255])

            compressed = zlib.compress(raw)
            ihdr = struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0)
            png  = b"\x89PNG\r\n\x1a\n"
            png += png_chunk(b"IHDR", ihdr)
            png += png_chunk(b"IDAT", compressed)
            png += png_chunk(b"IEND", b"")
            f.write(png)

        print("✅ Placeholder icon created: assets/icon.png")
        print("   For best results: install Pillow and run again")
        print("   Or replace assets/icon.png with your own 256x256 PNG")

if __name__ == "__main__":
    make_icon()
