; Nexus Suite — NSIS installer customization
; Built by TuckerLawson

!macro customHeader
  !system "echo Nexus Suite installer customization loaded"
!macroend

!macro customInstall
  ; Register app for Windows Search
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\App Paths\NexusSuite.exe" "" "$INSTDIR\NexusSuite.exe"

  ; Add to Windows Search index
  WriteRegStr HKCU "Software\Classes\Applications\NexusSuite.exe" "FriendlyAppName" "Nexus Suite"
  WriteRegStr HKCU "Software\Classes\Applications\NexusSuite.exe" "AppUserModelID" "TuckerLawson.NexusSuite"

  ; Create Start Menu entry
  CreateDirectory "$SMPROGRAMS\Nexus Suite"
  CreateShortCut "$SMPROGRAMS\Nexus Suite\Nexus Suite.lnk" "$INSTDIR\NexusSuite.exe" "" "$INSTDIR\NexusSuite.exe" 0
  CreateShortCut "$SMPROGRAMS\Nexus Suite\Uninstall Nexus Suite.lnk" "$INSTDIR\Uninstall NexusSuite.exe"

  ; Register in Add/Remove Programs
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\NexusSuite" "DisplayName" "Nexus Suite"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\NexusSuite" "Publisher" "TuckerLawson"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\NexusSuite" "DisplayVersion" "1.0.0"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\NexusSuite" "DisplayIcon" "$INSTDIR\NexusSuite.exe"
!macroend

!macro customUnInstall
  DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\App Paths\NexusSuite.exe"
  DeleteRegKey HKCU "Software\Classes\Applications\NexusSuite.exe"
  DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\NexusSuite"
  RMDir /r "$SMPROGRAMS\Nexus Suite"
!macroend
