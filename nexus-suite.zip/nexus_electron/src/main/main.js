const { app, BrowserWindow, ipcMain, shell, session } = require('electron')
const path = require('path')
const { spawn } = require('child_process')
const fs = require('fs')
const crypto = require('crypto')

// ── Google OAuth ─────────────────────────────────────
const GOOGLE_CLIENT_ID     = '5734757119-8e4egl8qmu4ojpo1nunj3nnscgk28vva.apps.googleusercontent.com'
const GOOGLE_CLIENT_SECRET = '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'
const REDIRECT_URI         = 'urn:ietf:wg:oauth:2.0:oob'
const SCOPES               = ['openid', 'email', 'profile']

// ── Paths ─────────────────────────────────────────────
const DATA_DIR = path.join(app.getPath('userData'), 'accounts')
const isDev    = !app.isPackaged

// ── Encryption ────────────────────────────────────────
const CIPHER_KEY = crypto.scryptSync('nexus-suite-key-TuckerLawson', 'salt', 32)

function encrypt(text) {
  const iv = crypto.randomBytes(16)
  const cipher = crypto.createCipheriv('aes-256-cbc', CIPHER_KEY, iv)
  const encrypted = Buffer.concat([cipher.update(text), cipher.final()])
  return iv.toString('hex') + ':' + encrypted.toString('hex')
}

function decrypt(text) {
  try {
    const [ivHex, encHex] = text.split(':')
    const iv = Buffer.from(ivHex, 'hex')
    const encrypted = Buffer.from(encHex, 'hex')
    const decipher = crypto.createDecipheriv('aes-256-cbc', CIPHER_KEY, iv)
    return Buffer.concat([decipher.update(encrypted), decipher.final()]).toString()
  } catch { return '' }
}

// ── Account Storage ───────────────────────────────────
function getAccountDir(userId) {
  const dir = path.join(DATA_DIR, userId)
  fs.mkdirSync(dir, { recursive: true })
  fs.mkdirSync(path.join(dir, 'sessions'), { recursive: true })
  fs.mkdirSync(path.join(dir, 'library'), { recursive: true })
  return dir
}

function loadProfile(userId) {
  const f = path.join(getAccountDir(userId), 'profile.json')
  return fs.existsSync(f) ? JSON.parse(fs.readFileSync(f, 'utf-8')) : null
}

function saveProfile(userId, profile) {
  const f = path.join(getAccountDir(userId), 'profile.json')
  fs.writeFileSync(f, JSON.stringify(profile, null, 2))
}

function loadKeys(userId) {
  const f = path.join(getAccountDir(userId), 'keys.enc')
  if (!fs.existsSync(f)) return {}
  try { return JSON.parse(decrypt(fs.readFileSync(f, 'utf-8'))) } catch { return {} }
}

function saveKeys(userId, keys) {
  const f = path.join(getAccountDir(userId), 'keys.enc')
  fs.writeFileSync(f, encrypt(JSON.stringify(keys)))
}

function loadConfig(userId) {
  const f = path.join(getAccountDir(userId), 'config.json')
  return fs.existsSync(f) ? JSON.parse(fs.readFileSync(f, 'utf-8')) : {}
}

function saveConfig(userId, config) {
  const f = path.join(getAccountDir(userId), 'config.json')
  fs.writeFileSync(f, JSON.stringify(config, null, 2))
}

function saveSession(userId, session) {
  const dir = path.join(getAccountDir(userId), 'sessions')
  const id  = `session_${Date.now()}`
  fs.writeFileSync(path.join(dir, `${id}.json`), JSON.stringify(session, null, 2))
  return id
}

function loadSessions(userId) {
  const dir = path.join(getAccountDir(userId), 'sessions')
  if (!fs.existsSync(dir)) return []
  return fs.readdirSync(dir)
    .filter(f => f.endsWith('.json'))
    .map(f => {
      try { return JSON.parse(fs.readFileSync(path.join(dir, f), 'utf-8')) }
      catch { return null }
    })
    .filter(Boolean)
    .sort((a, b) => new Date(b.created) - new Date(a.created))
}

function loadLibrary(userId) {
  const dir = path.join(getAccountDir(userId), 'library')
  if (!fs.existsSync(dir)) return []
  return fs.readdirSync(dir)
    .filter(f => f.endsWith('.json'))
    .map(f => {
      try { return JSON.parse(fs.readFileSync(path.join(dir, f), 'utf-8')) }
      catch { return null }
    })
    .filter(Boolean)
    .sort((a, b) => new Date(b.created) - new Date(a.created))
}

function saveLibraryEntry(userId, entry) {
  const dir = path.join(getAccountDir(userId), 'library')
  const id  = `lib_${Date.now()}`
  fs.writeFileSync(path.join(dir, `${id}.json`), JSON.stringify({ ...entry, id }, null, 2))
  return id
}

function deleteLibraryEntry(userId, id) {
  const f = path.join(getAccountDir(userId), 'library', `${id}.json`)
  if (fs.existsSync(f)) fs.unlinkSync(f)
}

// ── Python Backend Process ────────────────────────────
let pythonProc = null
let mainWindow = null

function getPythonPath() {
  if (isDev) return 'python'
  const bundled = path.join(process.resourcesPath, 'python', 'pipeline.py')
  return bundled
}

function startPythonBackend() {
  const pyScript = isDev
    ? path.join(__dirname, '../../python/pipeline.py')
    : path.join(process.resourcesPath, 'python', 'pipeline.py')

  if (!fs.existsSync(pyScript)) {
    console.log('Python script not found:', pyScript)
    return
  }

  pythonProc = spawn('python', [pyScript, '--mode', 'ipc'], {
    stdio: ['pipe', 'pipe', 'pipe']
  })

  pythonProc.stdout.on('data', (data) => {
    const lines = data.toString().split('\n').filter(Boolean)
    lines.forEach(line => {
      try {
        const msg = JSON.parse(line)
        if (mainWindow) mainWindow.webContents.send('pipeline:output', msg)
      } catch {
        if (mainWindow) mainWindow.webContents.send('pipeline:output', { agent: 'sys', text: line })
      }
    })
  })

  pythonProc.stderr.on('data', (data) => {
    if (mainWindow) mainWindow.webContents.send('pipeline:output', {
      agent: 'error', text: data.toString()
    })
  })

  pythonProc.on('exit', (code) => {
    if (mainWindow) mainWindow.webContents.send('pipeline:exit', { code })
    pythonProc = null
  })
}

// ── Google OAuth Flow ─────────────────────────────────
async function startGoogleAuth() {
  const authUrl =
    `https://accounts.google.com/o/oauth2/v2/auth` +
    `?client_id=${GOOGLE_CLIENT_ID}` +
    `&redirect_uri=${encodeURIComponent('http://localhost:42813/callback')}` +
    `&response_type=code` +
    `&scope=${encodeURIComponent(SCOPES.join(' '))}` +
    `&access_type=offline` +
    `&prompt=consent`

  return new Promise((resolve, reject) => {
    // Start local server to catch redirect
    const http = require('http')
    const server = http.createServer(async (req, res) => {
      const url = new URL(req.url, 'http://localhost:42813')
      if (url.pathname === '/callback') {
        const code = url.searchParams.get('code')
        res.writeHead(200, { 'Content-Type': 'text/html' })
        res.end(`<html><body style="background:#060610;color:#f1f5f9;font-family:Inter,sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;"><div style="text-align:center;"><h1 style="color:#7c3aed;">⬡ Nexus Suite</h1><p>Signed in successfully — you can close this window.</p></div></body></html>`)
        server.close()

        if (code) {
          try {
            // Exchange code for tokens
            const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
              method: 'POST',
              headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
              body: new URLSearchParams({
                code,
                client_id: GOOGLE_CLIENT_ID,
                client_secret: GOOGLE_CLIENT_SECRET,
                redirect_uri: 'http://localhost:42813/callback',
                grant_type: 'authorization_code',
              }).toString()
            })
            const tokens = await tokenRes.json()

            // Get user info
            const userRes = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
              headers: { Authorization: `Bearer ${tokens.access_token}` }
            })
            const user = await userRes.json()

            resolve({ tokens, user })
          } catch(e) { reject(e) }
        } else {
          reject(new Error('No auth code received'))
        }
      }
    })

    server.listen(42813, () => {
      shell.openExternal(authUrl)
    })

    // Timeout after 5 minutes
    setTimeout(() => { server.close(); reject(new Error('Auth timeout')) }, 300000)
  })
}

// ── IPC Handlers ──────────────────────────────────────
function registerIPC() {
  // AUTH
  ipcMain.handle('auth:google', async () => {
    try {
      const { tokens, user } = await startGoogleAuth()
      const userId = user.id
      const profile = {
        id:      userId,
        email:   user.email,
        name:    user.name,
        avatar:  user.picture,
        tokens,
        lastLogin: new Date().toISOString(),
      }
      saveProfile(userId, profile)
      return { ok: true, profile }
    } catch(e) {
      return { ok: false, error: e.message }
    }
  })

  ipcMain.handle('auth:logout', (_, userId) => {
    // Just return — local data stays, session token cleared in renderer
    return { ok: true }
  })

  ipcMain.handle('auth:get-profile', (_, userId) => {
    return loadProfile(userId)
  })

  // KEYS
  ipcMain.handle('keys:load', (_, userId) => loadKeys(userId))
  ipcMain.handle('keys:save', (_, { userId, keys }) => {
    saveKeys(userId, keys)
    return { ok: true }
  })

  // CONFIG
  ipcMain.handle('config:load', (_, userId) => loadConfig(userId))
  ipcMain.handle('config:save', (_, { userId, config }) => {
    saveConfig(userId, config)
    return { ok: true }
  })

  // SESSIONS
  ipcMain.handle('sessions:load', (_, userId) => loadSessions(userId))
  ipcMain.handle('sessions:save', (_, { userId, session }) => {
    return saveSession(userId, session)
  })

  // LIBRARY
  ipcMain.handle('library:load', (_, userId) => loadLibrary(userId))
  ipcMain.handle('library:save', (_, { userId, entry }) => {
    return saveLibraryEntry(userId, entry)
  })
  ipcMain.handle('library:delete', (_, { userId, id }) => {
    deleteLibraryEntry(userId, id)
    return { ok: true }
  })

  // PIPELINE
  ipcMain.handle('pipeline:run', (_, { task, keys, config, context }) => {
    if (!pythonProc) startPythonBackend()
    if (pythonProc) {
      const payload = JSON.stringify({ type: 'run', task, keys, config, context }) + '\n'
      pythonProc.stdin.write(payload)
    }
    return { ok: true }
  })

  ipcMain.handle('pipeline:cancel', () => {
    if (pythonProc) {
      pythonProc.stdin.write(JSON.stringify({ type: 'cancel' }) + '\n')
    }
    return { ok: true }
  })

  // SERVER CONTROL
  let serverProc = null
  ipcMain.handle('server:start', (_, { fxPath, dataPath }) => {
    if (serverProc) return { ok: false, error: 'Already running' }
    if (!fs.existsSync(fxPath)) return { ok: false, error: 'FXServer.exe not found' }
    try {
      serverProc = spawn(fxPath, ['+exec', 'server.cfg'], { cwd: dataPath })
      serverProc.stdout.on('data', d => {
        if (mainWindow) mainWindow.webContents.send('server:output', d.toString())
      })
      serverProc.stderr.on('data', d => {
        if (mainWindow) mainWindow.webContents.send('server:output', d.toString())
      })
      serverProc.on('exit', () => {
        serverProc = null
        if (mainWindow) mainWindow.webContents.send('server:status', { online: false })
      })
      if (mainWindow) mainWindow.webContents.send('server:status', { online: true })
      return { ok: true }
    } catch(e) { return { ok: false, error: e.message } }
  })

  ipcMain.handle('server:stop', () => {
    if (serverProc) { serverProc.kill(); serverProc = null }
    if (mainWindow) mainWindow.webContents.send('server:status', { online: false })
    return { ok: true }
  })

  ipcMain.handle('server:restart', async (event, args) => {
    if (serverProc) { serverProc.kill(); serverProc = null }
    await new Promise(r => setTimeout(r, 2000))
    return ipcMain.handle('server:start', event, args)
  })

  // FILES
  ipcMain.handle('files:read', (_, filePath) => {
    try { return { ok: true, content: fs.readFileSync(filePath, 'utf-8') }
    } catch(e) { return { ok: false, error: e.message } }
  })

  ipcMain.handle('files:write', (_, { filePath, content }) => {
    try { fs.writeFileSync(filePath, content, 'utf-8'); return { ok: true }
    } catch(e) { return { ok: false, error: e.message } }
  })

  ipcMain.handle('files:list', (_, dirPath) => {
    try {
      const items = fs.readdirSync(dirPath, { withFileTypes: true })
      return { ok: true, items: items.map(i => ({ name: i.name, isDir: i.isDirectory(), path: path.join(dirPath, i.name) })) }
    } catch(e) { return { ok: false, items: [] } }
  })

  ipcMain.handle('files:mkdir', (_, dirPath) => {
    try { fs.mkdirSync(dirPath, { recursive: true }); return { ok: true }
    } catch(e) { return { ok: false, error: e.message } }
  })

  // UTILS
  ipcMain.handle('shell:open', (_, p) => { shell.openPath(p); return { ok: true } })
  ipcMain.handle('shell:openUrl', (_, url) => { shell.openExternal(url); return { ok: true } })
  ipcMain.handle('dialog:openFile', async () => {
    const { dialog } = require('electron')
    const r = await dialog.showOpenDialog(mainWindow, { properties: ['openFile'], filters: [{ name: 'EXE', extensions: ['exe'] }] })
    return r.canceled ? null : r.filePaths[0]
  })
  ipcMain.handle('dialog:openDir', async () => {
    const { dialog } = require('electron')
    const r = await dialog.showOpenDialog(mainWindow, { properties: ['openDirectory'] })
    return r.canceled ? null : r.filePaths[0]
  })
}

// ── Window ────────────────────────────────────────────
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1200,
    minHeight: 720,
    frame: false,
    titleBarStyle: 'hidden',
    backgroundColor: '#060610',
    icon: path.join(__dirname, '../../assets/icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
    },
  })

  if (isDev) {
    mainWindow.loadURL('http://localhost:5173')
    mainWindow.webContents.openDevTools()
  } else {
    mainWindow.loadFile(path.join(__dirname, '../../dist/index.html'))
  }

  // Custom titlebar controls
  ipcMain.on('window:minimize', () => mainWindow.minimize())
  ipcMain.on('window:maximize', () => mainWindow.isMaximized() ? mainWindow.restore() : mainWindow.maximize())
  ipcMain.on('window:close', () => mainWindow.close())
}

app.whenReady().then(() => {
  registerIPC()
  createWindow()
  fs.mkdirSync(DATA_DIR, { recursive: true })
})

app.on('window-all-closed', () => {
  if (pythonProc) pythonProc.kill()
  if (process.platform !== 'darwin') app.quit()
})
