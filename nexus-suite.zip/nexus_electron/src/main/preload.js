const { contextBridge, ipcRenderer } = require('electron')

contextBridge.exposeInMainWorld('nexus', {
  // Window controls
  window: {
    minimize: () => ipcRenderer.send('window:minimize'),
    maximize: () => ipcRenderer.send('window:maximize'),
    close:    () => ipcRenderer.send('window:close'),
  },

  // Auth
  auth: {
    google:     ()         => ipcRenderer.invoke('auth:google'),
    logout:     (id)       => ipcRenderer.invoke('auth:logout', id),
    getProfile: (id)       => ipcRenderer.invoke('auth:get-profile', id),
  },

  // Keys (encrypted)
  keys: {
    load: (id)           => ipcRenderer.invoke('keys:load', id),
    save: (id, keys)     => ipcRenderer.invoke('keys:save', { userId: id, keys }),
  },

  // Config
  config: {
    load: (id)           => ipcRenderer.invoke('config:load', id),
    save: (id, cfg)      => ipcRenderer.invoke('config:save', { userId: id, config: cfg }),
  },

  // Sessions
  sessions: {
    load: (id)           => ipcRenderer.invoke('sessions:load', id),
    save: (id, s)        => ipcRenderer.invoke('sessions:save', { userId: id, session: s }),
  },

  // Library
  library: {
    load:   (id)         => ipcRenderer.invoke('library:load', id),
    save:   (id, entry)  => ipcRenderer.invoke('library:save', { userId: id, entry }),
    delete: (id, eid)    => ipcRenderer.invoke('library:delete', { userId: id, id: eid }),
  },

  // Pipeline
  pipeline: {
    run:    (args)       => ipcRenderer.invoke('pipeline:run', args),
    cancel: ()           => ipcRenderer.invoke('pipeline:cancel'),
    onOutput: (cb)       => ipcRenderer.on('pipeline:output', (_, d) => cb(d)),
    onExit:   (cb)       => ipcRenderer.on('pipeline:exit',   (_, d) => cb(d)),
    removeAllListeners: () => {
      ipcRenderer.removeAllListeners('pipeline:output')
      ipcRenderer.removeAllListeners('pipeline:exit')
    },
  },

  // Server
  server: {
    start:    (args)     => ipcRenderer.invoke('server:start', args),
    stop:     ()         => ipcRenderer.invoke('server:stop'),
    restart:  (args)     => ipcRenderer.invoke('server:restart', args),
    onOutput: (cb)       => ipcRenderer.on('server:output', (_, d) => cb(d)),
    onStatus: (cb)       => ipcRenderer.on('server:status', (_, d) => cb(d)),
    removeAllListeners: () => {
      ipcRenderer.removeAllListeners('server:output')
      ipcRenderer.removeAllListeners('server:status')
    },
  },

  // Files
  files: {
    read:   (p)          => ipcRenderer.invoke('files:read', p),
    write:  (p, c)       => ipcRenderer.invoke('files:write', { filePath: p, content: c }),
    list:   (p)          => ipcRenderer.invoke('files:list', p),
    mkdir:  (p)          => ipcRenderer.invoke('files:mkdir', p),
  },

  // Shell / dialogs
  shell: {
    open:    (p)         => ipcRenderer.invoke('shell:open', p),
    openUrl: (u)         => ipcRenderer.invoke('shell:openUrl', u),
  },
  dialog: {
    openFile: ()         => ipcRenderer.invoke('dialog:openFile'),
    openDir:  ()         => ipcRenderer.invoke('dialog:openDir'),
  },
})
