import React from 'react'
import { motion } from 'framer-motion'
import { useStore } from '../store'

const NAV = [
  { key: 'dashboard', icon: '⬡',  label: 'Dashboard',   color: '#a78bfa' },
  { key: 'ai',        icon: '🧠',  label: 'Nexus AI Core', color: '#a78bfa' },
  { key: 'server',    icon: '🖥️',  label: 'Server Panel', color: '#34d399' },
  { key: 'files',     icon: '📁',  label: 'File Manager', color: '#fbbf24' },
  { key: 'library',   icon: '📚',  label: 'Library',      color: '#2dd4bf' },
  { key: 'history',   icon: '🕐',  label: 'History',      color: '#38bdf8' },
  { key: 'webtools',  icon: '🌐',  label: 'Web Tools',    color: '#f472b6' },
]

const AGENTS = [
  { key: 'claude',   color: '#a78bfa', label: 'C' },
  { key: 'gpt',      color: '#34d399', label: 'G' },
  { key: 'grok',     color: '#38bdf8', label: 'X' },
  { key: 'gemini',   color: '#fbbf24', label: 'Ge' },
  { key: 'perp',     color: '#2dd4bf', label: 'P' },
  { key: 'nexus_ai', color: '#f472b6', label: 'N' },
]

export default function Sidebar() {
  const { page, setPage, user, isGuest, logout, agentStatus, agentConf, pipelineRunning } = useStore()

  const handleLogout = () => {
    logout()
    localStorage.removeItem('nexus_user')
  }

  return (
    <aside className="w-56 h-full flex flex-col border-r border-nexus-border bg-nexus-card/60 backdrop-blur-xl flex-shrink-0">

      {/* User profile */}
      <div className="p-4 border-b border-nexus-border">
        {user ? (
          <div className="flex items-center gap-3">
            <img
              src={user.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name)}&background=7c3aed&color=fff`}
              alt={user.name}
              className="w-9 h-9 rounded-full ring-2 ring-purple-500/30"
              onError={e => { e.target.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name || 'U')}&background=7c3aed&color=fff` }}
            />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-nexus-text truncate">{user.name}</p>
              <p className="text-xs text-nexus-faint truncate">{user.email}</p>
            </div>
          </div>
        ) : (
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-nexus-card2 border border-nexus-border flex items-center justify-center text-nexus-faint text-sm">
              👤
            </div>
            <div>
              <p className="text-sm font-semibold text-nexus-text">Guest</p>
              <p className="text-xs text-nexus-faint">Not signed in</p>
            </div>
          </div>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto scrollable">
        {NAV.map(({ key, icon, label, color }) => {
          const active = page === key
          return (
            <button
              key={key}
              onClick={() => setPage(key)}
              className={`relative w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-150 text-left nav-item ${active ? 'active' : ''}`}
            >
              {active && (
                <motion.div
                  layoutId="sidebar-indicator"
                  className="sidebar-indicator"
                  style={{ backgroundColor: color }}
                />
              )}
              <span className="text-base">{icon}</span>
              <span className={active ? 'text-nexus-text' : 'text-nexus-muted'}>{label}</span>
              {active && (
                <motion.div
                  layoutId="active-bg"
                  className="absolute inset-0 rounded-xl"
                  style={{ background: `${color}15`, border: `1px solid ${color}30` }}
                />
              )}
            </button>
          )
        })}

        <div className="pt-2 border-t border-nexus-border mt-2">
          <button
            onClick={() => setPage('settings')}
            className={`relative w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-150 text-left nav-item ${page === 'settings' ? 'active' : ''}`}
          >
            <span className="text-base">⚙️</span>
            <span className={page === 'settings' ? 'text-nexus-text' : 'text-nexus-muted'}>Settings</span>
          </button>
        </div>
      </nav>

      {/* Agent status mini panel */}
      {pipelineRunning && (
        <div className="p-3 border-t border-nexus-border">
          <p className="text-xs font-semibold text-nexus-faint uppercase tracking-wider mb-2">Agents Active</p>
          <div className="flex flex-wrap gap-1.5">
            {AGENTS.map(({ key, color, label }) => {
              const status = agentStatus[key]
              const conf   = agentConf[key]
              return (
                <div
                  key={key}
                  title={`${key}: ${status} ${conf ? conf + '%' : ''}`}
                  className="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold relative"
                  style={{
                    background: status === 'working' ? `${color}30` : status === 'done' ? '#10b98120' : '#1e1e3f',
                    border: `1px solid ${status === 'working' ? color : status === 'done' ? '#10b981' : '#2a2a55'}`,
                    color: status === 'idle' ? '#475569' : color,
                    boxShadow: status === 'working' ? `0 0 8px ${color}40` : 'none',
                  }}
                >
                  {label}
                  {status === 'working' && (
                    <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-yellow-400 animate-pulse" />
                  )}
                  {status === 'done' && (
                    <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-green-400" />
                  )}
                </div>
              )
            })}
          </div>
        </div>
      )}

      {/* Footer */}
      <div className="p-3 border-t border-nexus-border">
        {user ? (
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs text-nexus-faint hover:text-red-400 hover:bg-red-500/10 transition-all"
          >
            <span>🚪</span>
            <span>Sign Out</span>
          </button>
        ) : (
          <button
            onClick={() => { useStore.getState().logout() }}
            className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs text-nexus-faint hover:text-nexus-purple hover:bg-purple-500/10 transition-all"
          >
            <span>🔑</span>
            <span>Sign In with Google</span>
          </button>
        )}
        <p className="text-center text-[10px] text-nexus-faint mt-2">Built by TuckerLawson</p>
      </div>
    </aside>
  )
}
