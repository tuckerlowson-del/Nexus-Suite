import React from 'react'
import { useStore } from '../store'

export default function TitleBar({ minimal = false }) {
  const { user, serverOnline, pipelinePhase, pipelinePhaseNum } = useStore()

  const minimize = () => window.nexus?.window.minimize()
  const maximize = () => window.nexus?.window.maximize()
  const close    = () => window.nexus?.window.close()

  return (
    <div className="drag-region h-12 flex items-center justify-between px-4 border-b border-nexus-border bg-nexus-card/80 backdrop-blur-xl flex-shrink-0 z-50">
      {/* Left — Logo */}
      <div className="flex items-center gap-3 no-drag">
        <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-purple-600 to-violet-800 flex items-center justify-center text-sm font-bold shadow-lg">
          ⬡
        </div>
        <span className="text-sm font-semibold text-nexus-text tracking-wide">NEXUS SUITE</span>
        <span className="text-xs text-nexus-faint">v1.0</span>
      </div>

      {/* Center — Phase indicator */}
      {!minimal && pipelinePhase && (
        <div className="flex items-center gap-2 no-drag">
          <div className="badge badge-purple animate-pulse-slow">
            <span className="w-1.5 h-1.5 rounded-full bg-purple-400 animate-pulse" />
            Phase {pipelinePhaseNum}/8 — {pipelinePhase}
          </div>
        </div>
      )}

      {/* Server status pill */}
      {!minimal && (
        <div className="flex items-center gap-2 no-drag">
          <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border ${
            serverOnline
              ? 'bg-green-500/10 border-green-500/30 text-green-400'
              : 'bg-red-500/10 border-red-500/30 text-red-400'
          }`}>
            <span className={`w-1.5 h-1.5 rounded-full ${serverOnline ? 'bg-green-400 animate-pulse' : 'bg-red-400'}`} />
            {serverOnline ? 'SERVER ONLINE' : 'SERVER OFFLINE'}
          </div>
        </div>
      )}

      {/* Right — Window controls */}
      <div className="flex items-center gap-1 no-drag">
        <button onClick={minimize}
          className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-nexus-card2 transition-colors text-nexus-muted hover:text-nexus-text">
          <svg width="10" height="2" viewBox="0 0 10 2" fill="currentColor">
            <rect width="10" height="2" rx="1"/>
          </svg>
        </button>
        <button onClick={maximize}
          className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-nexus-card2 transition-colors text-nexus-muted hover:text-nexus-text">
          <svg width="10" height="10" viewBox="0 0 10 10" fill="none" stroke="currentColor" strokeWidth="1.5">
            <rect x="0.75" y="0.75" width="8.5" height="8.5" rx="1.5"/>
          </svg>
        </button>
        <button onClick={close}
          className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-red-500/20 transition-colors text-nexus-muted hover:text-red-400">
          <svg width="10" height="10" viewBox="0 0 10 10" fill="none" stroke="currentColor" strokeWidth="1.5">
            <path d="M1 1l8 8M9 1L1 9"/>
          </svg>
        </button>
      </div>
    </div>
  )
}
