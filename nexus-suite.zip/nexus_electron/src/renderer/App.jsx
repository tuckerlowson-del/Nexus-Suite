import React, { useEffect, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { useStore } from './store'
import TitleBar from './components/TitleBar'
import Sidebar from './components/Sidebar'
import LoginPage from './pages/LoginPage'
import DashboardPage from './pages/DashboardPage'
import AICorePage from './pages/AICorePage'
import ServerPanelPage from './pages/ServerPanelPage'
import FilesPage from './pages/FilesPage'
import LibraryPage from './pages/LibraryPage'
import HistoryPage from './pages/HistoryPage'
import WebToolsPage from './pages/WebToolsPage'
import SettingsPage from './pages/SettingsPage'

const PAGES = {
  dashboard: DashboardPage,
  ai:        AICorePage,
  server:    ServerPanelPage,
  files:     FilesPage,
  library:   LibraryPage,
  history:   HistoryPage,
  webtools:  WebToolsPage,
  settings:  SettingsPage,
}

export default function App() {
  const { user, isGuest, page, setServerOnline, addServerOutput } = useStore()
  const [loading, setLoading] = useState(true)

  // Restore session from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('nexus_user')
    if (saved) {
      try {
        const u = JSON.parse(saved)
        useStore.getState().setUser(u)
      } catch {}
    }
    setLoading(false)
  }, [])

  // Wire up server events
  useEffect(() => {
    if (!window.nexus) return
    window.nexus.server.onOutput(line => addServerOutput(line))
    window.nexus.server.onStatus(({ online }) => setServerOnline(online))
    return () => window.nexus.server.removeAllListeners()
  }, [])

  // Save user to localStorage when it changes
  useEffect(() => {
    if (user) localStorage.setItem('nexus_user', JSON.stringify(user))
    else localStorage.removeItem('nexus_user')
  }, [user])

  if (loading) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-nexus-bg">
        <div className="flex flex-col items-center gap-4">
          <div className="text-4xl animate-spin-slow">⬡</div>
          <p className="text-nexus-muted text-sm">Loading Nexus Suite...</p>
        </div>
      </div>
    )
  }

  // Not logged in and not guest → show login
  if (!user && !isGuest) {
    return (
      <div className="w-full h-full flex flex-col">
        <TitleBar minimal />
        <LoginPage />
      </div>
    )
  }

  const PageComponent = PAGES[page] || DashboardPage

  return (
    <div className="w-full h-full flex flex-col bg-nexus-bg">
      <TitleBar />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar />
        <main className="flex-1 overflow-hidden relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={page}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.2, ease: 'easeOut' }}
              className="h-full overflow-y-auto scrollable"
            >
              <PageComponent />
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  )
}
