import React, { useState, useEffect, useRef } from 'react'
import { motion } from 'framer-motion'
import { useStore } from '../store'

export default function ServerPanelPage() {
  const { config, serverOnline, serverOutput, setServerOnline, clearServerOutput } = useStore()
  const [cfgContent, setCfgContent] = useState('')
  const [cfgSaved, setCfgSaved]     = useState(false)
  const [stats, setStats]           = useState({ cpu: 0, ram: 0, storage: 35, players: 0 })
  const consoleRef = useRef(null)

  useEffect(() => {
    if (consoleRef.current) consoleRef.current.scrollTop = consoleRef.current.scrollHeight
  }, [serverOutput])

  useEffect(() => {
    if (serverOnline) {
      const iv = setInterval(() => {
        setStats({
          cpu:     Math.floor(Math.random() * 30 + 15),
          ram:     Math.floor(Math.random() * 30 + 40),
          storage: 35,
          players: Math.floor(Math.random() * 8),
        })
      }, 3000)
      return () => clearInterval(iv)
    } else {
      setStats({ cpu: 0, ram: 0, storage: 35, players: 0 })
    }
  }, [serverOnline])

  const loadCfg = async () => {
    if (!config.serverData) return
    const r = await window.nexus.files.read(`${config.serverData}/server.cfg`)
    if (r.ok) setCfgContent(r.content)
  }

  const saveCfg = async () => {
    if (!config.serverData) return
    await window.nexus.files.write(`${config.serverData}/server.cfg`, cfgContent)
    setCfgSaved(true)
    setTimeout(() => setCfgSaved(false), 2000)
  }

  const startServer = async () => {
    const r = await window.nexus.server.start({ fxPath: config.fxserverExe, dataPath: config.serverData })
    if (r.ok) setServerOnline(true)
    else alert('Failed to start: ' + r.error)
  }

  const stopServer = async () => {
    await window.nexus.server.stop()
    setServerOnline(false)
  }

  const restartServer = async () => {
    await stopServer()
    setTimeout(startServer, 2000)
  }

  const StatBar = ({ label, value, color }) => (
    <div>
      <div className="flex justify-between text-xs mb-1">
        <span className="text-nexus-faint">{label}</span>
        <span className="font-semibold" style={{ color }}>{value}%</span>
      </div>
      <div className="h-1.5 rounded-full bg-nexus-border overflow-hidden">
        <motion.div
          className="h-full rounded-full"
          style={{ background: color }}
          initial={{ width: 0 }}
          animate={{ width: `${value}%` }}
          transition={{ duration: 0.5 }}
        />
      </div>
    </div>
  )

  return (
    <div className="h-full flex flex-col">
      <div className="flex-shrink-0 px-6 py-4 border-b border-nexus-border bg-nexus-card/50">
        <h1 className="text-xl font-bold text-nexus-text">🖥️ Server Panel</h1>
        <p className="text-xs text-nexus-faint mt-0.5">HTN Panel clone — manage your FiveM server</p>
      </div>

      <div className="flex-1 flex overflow-hidden p-6 gap-6">
        {/* Left */}
        <div className="w-72 flex-shrink-0 space-y-4">
          {/* Server card */}
          <div className="glass-card p-5">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-xl bg-purple-500/20 border border-purple-500/30 flex items-center justify-center text-2xl">🎮</div>
              <div>
                <p className="font-semibold text-nexus-text text-sm">{config.serverName || 'My FiveM Server'}</p>
                <p className="text-xs text-nexus-faint">FiveM Server</p>
              </div>
              <div className={`ml-auto flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${
                serverOnline ? 'bg-green-500/15 border border-green-500/25 text-green-400' : 'bg-red-500/15 border border-red-500/25 text-red-400'
              }`}>
                <span className={`w-1.5 h-1.5 rounded-full ${serverOnline ? 'bg-green-400 animate-pulse' : 'bg-red-400'}`} />
                {serverOnline ? 'Online' : 'Offline'}
              </div>
            </div>

            <div className="bg-nexus-card3 rounded-xl p-3 grid grid-cols-4 gap-2 mb-4 text-center">
              {[
                { label: 'CPU',     value: `${stats.cpu}%`,     color: '#a78bfa' },
                { label: 'RAM',     value: `${stats.ram}%`,     color: '#34d399' },
                { label: 'Disk',    value: `${stats.storage}%`, color: '#fbbf24' },
                { label: 'Players', value: stats.players,        color: '#2dd4bf' },
              ].map(({ label, value, color }) => (
                <div key={label}>
                  <p className="text-sm font-bold" style={{ color }}>{value}</p>
                  <p className="text-[9px] text-nexus-faint mt-0.5">{label}</p>
                </div>
              ))}
            </div>

            <p className="text-xs text-nexus-faint mb-4">
              🌐 127.0.0.1:{config.serverPort || '30120'}
            </p>

            <div className="grid grid-cols-3 gap-2">
              {[
                { label: '▶ Start',    color: '#10b981', action: startServer,   disabled: serverOnline  },
                { label: '⏹ Stop',     color: '#f43f5e', action: stopServer,    disabled: !serverOnline },
                { label: '🔄 Restart', color: '#f59e0b', action: restartServer, disabled: false         },
              ].map(({ label, color, action, disabled }) => (
                <button key={label} onClick={action} disabled={disabled}
                  className="py-2 rounded-lg text-xs font-bold transition-all disabled:opacity-30 disabled:cursor-not-allowed"
                  style={{ background: `${color}20`, border: `1px solid ${color}40`, color }}>
                  {label}
                </button>
              ))}
            </div>
          </div>

          {/* Stats */}
          {serverOnline && (
            <div className="glass-card p-4 space-y-3">
              <p className="text-xs font-semibold text-nexus-faint uppercase tracking-wider">Live Stats</p>
              <StatBar label="CPU Usage"  value={stats.cpu}  color="#a78bfa" />
              <StatBar label="RAM Usage"  value={stats.ram}  color="#34d399" />
              <StatBar label="Disk Usage" value={stats.storage} color="#fbbf24" />
            </div>
          )}

          {/* Quick actions */}
          <div className="glass-card p-4 space-y-2">
            <p className="text-xs font-semibold text-nexus-faint uppercase tracking-wider mb-3">Quick Actions</p>
            {[
              { label: '📝 Load server.cfg', action: loadCfg },
              { label: '📂 Open Resources',  action: () => window.nexus.shell.open(config.resourcesPath) },
              { label: '💾 Create Backup',   action: async () => {
                if (config.serverData) await window.nexus.files.mkdir(`${config.serverData}/../nexus_backups`)
              }},
            ].map(({ label, action }) => (
              <button key={label} onClick={action}
                className="w-full text-left px-3 py-2.5 rounded-lg btn-ghost text-xs font-medium text-nexus-muted hover:text-nexus-text">
                {label}
              </button>
            ))}
          </div>
        </div>

        {/* Right — tabs */}
        <div className="flex-1 flex flex-col glass-card overflow-hidden">
          {/* Tab headers */}
          <div className="flex border-b border-nexus-border px-4">
            {['📊 Console', '📝 server.cfg'].map((t, i) => {
              const [active, setActive] = React.useState(0)
              // eslint-disable-next-line react-hooks/rules-of-hooks
              const [tab, setTab] = React.useState ? [0, setActive] : [0, () => {}]
              return null
            })}
          </div>

          {/* Two-tab layout inline */}
          <ServerTabs
            cfgContent={cfgContent}
            setCfgContent={setCfgContent}
            saveCfg={saveCfg}
            cfgSaved={cfgSaved}
            consoleRef={consoleRef}
            serverOutput={serverOutput}
            clearServerOutput={clearServerOutput}
          />
        </div>
      </div>
    </div>
  )
}

function ServerTabs({ cfgContent, setCfgContent, saveCfg, cfgSaved, consoleRef, serverOutput, clearServerOutput }) {
  const [tab, setTab] = useState('console')

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <div className="flex border-b border-nexus-border px-4">
        {[['console','📊 Console'],['cfg','📝 server.cfg']].map(([k, label]) => (
          <button key={k} onClick={() => setTab(k)}
            className={`px-4 py-3 text-xs font-semibold border-b-2 transition-all ${
              tab === k ? 'text-nexus-purple border-nexus-accent' : 'text-nexus-faint border-transparent hover:text-nexus-muted'
            }`}>
            {label}
          </button>
        ))}
        {tab === 'console' && (
          <button onClick={clearServerOutput}
            className="ml-auto my-2 px-3 py-1.5 rounded-lg btn-ghost text-xs text-nexus-faint">
            🗑️ Clear
          </button>
        )}
        {tab === 'cfg' && (
          <button onClick={saveCfg}
            className={`ml-auto my-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              cfgSaved ? 'bg-green-500/20 text-green-400 border border-green-500/30' : 'btn-primary text-white'
            }`}>
            {cfgSaved ? '✅ Saved!' : '💾 Save'}
          </button>
        )}
      </div>

      <div className="flex-1 overflow-hidden">
        {tab === 'console' && (
          <div ref={consoleRef} className="h-full p-4 overflow-y-auto scrollable terminal text-xs">
            {serverOutput.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-nexus-faint">
                <p className="text-3xl mb-3">📊</p>
                <p>Server console output appears here</p>
                <p className="text-xs mt-1">Start the server to see live output</p>
              </div>
            ) : (
              serverOutput.map((line, i) => {
                const isError = /error|failed|crash/i.test(line)
                const isWarn  = /warn|warning/i.test(line)
                return (
                  <div key={i} className={`mb-0.5 ${isError ? 'text-red-400' : isWarn ? 'text-yellow-400' : 'text-nexus-muted'}`}>
                    {line}
                  </div>
                )
              })
            )}
          </div>
        )}

        {tab === 'cfg' && (
          <textarea
            value={cfgContent}
            onChange={e => setCfgContent(e.target.value)}
            className="w-full h-full p-4 bg-transparent text-nexus-text font-mono text-xs resize-none outline-none scrollable"
            placeholder="Load server.cfg to edit it here..."
            style={{ userSelect: 'text' }}
          />
        )}
      </div>
    </div>
  )
}
