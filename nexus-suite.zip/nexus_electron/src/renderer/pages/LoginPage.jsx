import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { useStore } from '../store'

export default function LoginPage() {
  const { setUser, setGuest } = useStore()
  const [loading, setLoading] = useState(false)
  const [error,   setError]   = useState('')

  const handleGoogle = async () => {
    setLoading(true)
    setError('')
    try {
      const result = await window.nexus.auth.google()
      if (result.ok) {
        setUser(result.profile)
        // Load saved keys and config
        const keys   = await window.nexus.keys.load(result.profile.id)
        const config = await window.nexus.config.load(result.profile.id)
        if (keys)   useStore.getState().setKeys(keys)
        if (config) useStore.getState().setConfig({ ...useStore.getState().config, ...config })
      } else {
        setError(result.error || 'Sign in failed')
      }
    } catch(e) {
      setError(e.message || 'Something went wrong')
    }
    setLoading(false)
  }

  return (
    <div className="flex-1 relative flex items-center justify-center overflow-hidden bg-nexus-bg">
      {/* Background orbs */}
      <div className="bg-orb w-96 h-96 bg-purple-600 top-[-100px] left-[-100px]" />
      <div className="bg-orb w-80 h-80 bg-cyan-500 bottom-[-80px] right-[-80px]" />
      <div className="bg-orb w-64 h-64 bg-violet-700 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />

      {/* Animated grid background */}
      <div className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: 'linear-gradient(rgba(124,58,237,0.3) 1px, transparent 1px), linear-gradient(90deg, rgba(124,58,237,0.3) 1px, transparent 1px)',
          backgroundSize: '40px 40px'
        }}
      />

      {/* Login card */}
      <motion.div
        initial={{ opacity: 0, y: 24, scale: 0.97 }}
        animate={{ opacity: 1, y: 0,  scale: 1 }}
        transition={{ duration: 0.4, ease: 'easeOut' }}
        className="relative z-10 w-full max-w-md mx-6"
      >
        <div className="glass rounded-2xl p-10 shadow-nexus-lg text-center">

          {/* Logo */}
          <motion.div
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.1, duration: 0.5, type: 'spring' }}
            className="mb-8"
          >
            <div className="w-20 h-20 mx-auto rounded-2xl bg-gradient-to-br from-purple-600 via-violet-700 to-indigo-800 flex items-center justify-center text-4xl shadow-nexus-lg mb-4 animate-glow">
              ⬡
            </div>
            <h1 className="text-3xl font-black gradient-text mb-2">NEXUS SUITE</h1>
            <p className="text-nexus-muted text-sm">FiveM AI Development Platform</p>
            <p className="text-nexus-faint text-xs mt-1">Built by TuckerLawson</p>
          </motion.div>

          {/* Features */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="grid grid-cols-2 gap-3 mb-8"
          >
            {[
              { icon: '🧠', text: '6 AI Agents' },
              { icon: '⚡', text: '8 Build Phases' },
              { icon: '💾', text: 'Saves Your History' },
              { icon: '🆓', text: 'Free Forever' },
            ].map(({ icon, text }) => (
              <div key={text} className="glass-card p-3 flex items-center gap-2 text-left">
                <span className="text-lg">{icon}</span>
                <span className="text-xs font-medium text-nexus-muted">{text}</span>
              </div>
            ))}
          </motion.div>

          {/* Sign in button */}
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="space-y-3"
          >
            <button
              onClick={handleGoogle}
              disabled={loading}
              className="w-full flex items-center justify-center gap-3 px-6 py-4 rounded-xl font-semibold text-sm transition-all bg-white hover:bg-gray-50 text-gray-800 shadow-lg hover:shadow-xl hover:-translate-y-0.5 active:translate-y-0 disabled:opacity-60 disabled:cursor-not-allowed"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-gray-300 border-t-gray-600 rounded-full animate-spin" />
              ) : (
                <svg width="20" height="20" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                </svg>
              )}
              {loading ? 'Opening Google...' : 'Sign in with Google'}
            </button>

            <button
              onClick={setGuest}
              className="w-full px-6 py-3.5 rounded-xl text-sm font-medium text-nexus-muted hover:text-nexus-text btn-ghost"
            >
              Continue as Guest
              <span className="block text-xs text-nexus-faint mt-0.5">Chats won't be saved</span>
            </button>
          </motion.div>

          {error && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="mt-4 text-sm text-red-400 bg-red-500/10 border border-red-500/20 rounded-lg p-3"
            >
              ❌ {error}
            </motion.p>
          )}
        </div>
      </motion.div>
    </div>
  )
}
