import React, { useState, useCallback } from 'react'
import { motion } from 'framer-motion'
import Editor from '@monaco-editor/react'
import { useStore } from '../store'

const FILE_ICONS = { lua: '🟧', js: '🟨', html: '🟦', css: '🎨', json: '📋', sql: '🗄️', cfg: '⚙️', md: '📝' }
const getIcon = name => FILE_ICONS[name.split('.').pop()] || '📄'
const getLang = name => {
  const ext = name.split('.').pop()
  return { lua: 'lua', js: 'javascript', html: 'html', css: 'css', json: 'json', sql: 'sql', cfg: 'ini', md: 'markdown' }[ext] || 'plaintext'
}

function FileTree({ items, onSelect, selected, depth = 0 }) {
  const [open, setOpen] = useState({})
  const { config } = useStore()

  if (!items || items.length === 0) return (
    <div className="text-center py-8 text-nexus-faint text-xs">
      {config.resourcesPath ? 'Empty folder' : 'Set Resources Path in Settings'}
    </div>
  )

  return (
    <div>
      {items.map(item => (
        <div key={item.path}>
          <button
            onClick={() => {
              if (item.isDir) setOpen(o => ({ ...o, [item.path]: !o[item.path] }))
              else onSelect(item)
            }}
            className={`w-full flex items-center gap-2 px-2 py-1.5 rounded-lg text-xs transition-all text-left ${
              selected === item.path
                ? 'bg-purple-500/20 text-nexus-text border border-purple-500/30'
                : 'hover:bg-nexus-card2 text-nexus-muted'
            }`}
            style={{ paddingLeft: `${8 + depth * 16}px` }}
          >
            {item.isDir ? (
              <span className="text-nexus-faint">{open[item.path] ? '▾' : '▸'}</span>
            ) : (
              <span>{getIcon(item.name)}</span>
            )}
            <span className="truncate">{item.name}</span>
          </button>
          {item.isDir && open[item.path] && item.children && (
            <FileTree items={item.children} onSelect={onSelect} selected={selected} depth={depth + 1} />
          )}
        </div>
      ))}
    </div>
  )
}

export default function FilesPage() {
  const { config, keys, user } = useStore()
  const [tree,    setTree]    = useState([])
  const [selFile, setSelFile] = useState(null)
  const [content, setContent] = useState('')
  const [saved,   setSaved]   = useState(false)
  const [fixing,  setFixing]  = useState(false)
  const [loaded,  setLoaded]  = useState(false)

  const loadTree = async () => {
    if (!config.resourcesPath) return
    const r = await window.nexus.files.list(config.resourcesPath)
    if (!r.ok) return

    const withChildren = await Promise.all(r.items.map(async item => {
      if (!item.isDir) return item
      const sub = await window.nexus.files.list(item.path)
      return { ...item, children: sub.ok ? sub.items : [] }
    }))
    setTree(withChildren)
    setLoaded(true)
  }

  const openFile = async (item) => {
    setSelFile(item)
    const r = await window.nexus.files.read(item.path)
    if (r.ok) setContent(r.content)
  }

  const saveFile = async () => {
    if (!selFile) return
    await window.nexus.files.write(selFile.path, content)
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  const aiFix = async () => {
    if (!selFile || !content) return
    setFixing(true)
    // Send to pipeline AI fix
    await window.nexus.pipeline.run({
      task: `Fix all bugs in this file: ${selFile.name}\n\nFile content:\n${content}`,
      keys, config, context: {}
    })
    setFixing(false)
  }

  return (
    <div className="h-full flex flex-col">
      <div className="flex-shrink-0 px-6 py-4 border-b border-nexus-border bg-nexus-card/50">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-nexus-text">📁 File Manager</h1>
            <p className="text-xs text-nexus-faint mt-0.5">Browse and edit your server files</p>
          </div>
          <button onClick={loadTree}
            className="btn-ghost px-4 py-2 rounded-xl text-xs font-semibold text-nexus-muted hover:text-nexus-text flex items-center gap-2">
            🔄 {loaded ? 'Refresh' : 'Load Files'}
          </button>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Tree */}
        <div className="w-64 flex-shrink-0 border-r border-nexus-border p-3 overflow-y-auto scrollable bg-nexus-card/30">
          <p className="text-[10px] font-semibold text-nexus-faint uppercase tracking-wider mb-3 px-2">Resources</p>
          {!loaded ? (
            <div className="text-center py-12">
              <p className="text-2xl mb-2">📁</p>
              <p className="text-xs text-nexus-faint">Click Load Files to browse</p>
              {!config.resourcesPath && (
                <p className="text-xs text-nexus-faint mt-2">Set path in Settings first</p>
              )}
            </div>
          ) : (
            <FileTree items={tree} onSelect={openFile} selected={selFile?.path} />
          )}
        </div>

        {/* Editor */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {selFile ? (
            <>
              <div className="flex-shrink-0 flex items-center gap-3 px-4 py-3 border-b border-nexus-border bg-nexus-card/50">
                <span className="text-base">{getIcon(selFile.name)}</span>
                <span className="text-sm font-semibold text-nexus-text">{selFile.name}</span>
                <span className="text-xs text-nexus-faint">{selFile.path}</span>
                <div className="ml-auto flex gap-2">
                  <button onClick={aiFix} disabled={fixing}
                    className="px-3 py-1.5 rounded-lg btn-ghost text-xs font-medium text-nexus-muted hover:text-nexus-text disabled:opacity-50 flex items-center gap-1.5">
                    {fixing ? <><div className="w-3 h-3 border border-nexus-faint border-t-nexus-purple rounded-full animate-spin" />Fixing...</> : '🤖 AI Fix'}
                  </button>
                  <button onClick={saveFile}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                      saved ? 'bg-green-500/20 text-green-400 border border-green-500/30' : 'btn-primary text-white'
                    }`}>
                    {saved ? '✅ Saved!' : '💾 Save'}
                  </button>
                </div>
              </div>
              <div className="flex-1 overflow-hidden">
                <Editor
                  height="100%"
                  language={getLang(selFile.name)}
                  value={content}
                  onChange={v => setContent(v || '')}
                  theme="vs-dark"
                  options={{
                    fontSize: 13,
                    fontFamily: "'JetBrains Mono', 'Fira Code', monospace",
                    minimap: { enabled: false },
                    scrollBeyondLastLine: false,
                    padding: { top: 16, bottom: 16 },
                    lineNumbers: 'on',
                    renderLineHighlight: 'all',
                    cursorBlinking: 'smooth',
                    smoothScrolling: true,
                    contextmenu: true,
                    formatOnPaste: true,
                    formatOnType: true,
                    automaticLayout: true,
                  }}
                />
              </div>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-nexus-faint">
              <p className="text-5xl mb-4">📝</p>
              <p className="text-sm font-medium">Select a file to edit</p>
              <p className="text-xs mt-1">VS Code-powered Monaco editor</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
