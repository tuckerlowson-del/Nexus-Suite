import React, { useState, useEffect, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useStore } from '../store'

const AGENT_META = {
  claude:   { name: 'Claude',     color: '#a78bfa', icon: '🗂️', role: 'Planner + Reviewer' },
  gpt:      { name: 'GPT-4o',    color: '#34d399', icon: '💻', role: 'Lead Coder'         },
  grok:     { name: 'Grok',      color: '#38bdf8', icon: '🐛', role: 'Bug Hunter'         },
  gemini:   { name: 'Gemini',    color: '#fbbf24', icon: '🎨', role: 'UI/NUI Designer'    },
  perp:     { name: 'Perplexity',color: '#2dd4bf', icon: '🔍', role: 'QA Tester'         },
  nexus_ai: { name: 'Nexus AI',  color: '#f472b6', icon: '⬡',  role: 'FiveM Validator'   },
}

const FRAMEWORKS = ['QBCore', 'ESX', 'Qbox', 'Standalone', 'Custom']

const PHASE_COLORS = {
  1: '#a78bfa', 2: '#a78bfa', 3: '#34d399',
  4: '#38bdf8', 5: '#fbbf24', 6: '#2dd4bf',
  7: '#f43f5e', 8: '#10b981', 9: '#10b981',
}

function AgentCard({ agentKey }) {
  const { agentStatus, agentConf } = useStore()
  const meta   = AGENT_META[agentKey]
  const status = agentStatus[agentKey] || 'idle'
  const conf   = agentConf[agentKey]   || 0

  return (
    <div className={`agent-card p-3 ${status}`}>
      <div className="flex items-center gap-2.5">
        <div className="w-9 h-9 rounded-xl flex items-center justify-center text-base flex-shrink-0"
          style={{
            background: `${meta.color}20`,
            border: `1px solid ${status === 'idle' ? meta.color + '30' : meta.color}`,
            boxShadow: status === 'working' ? `0 0 12px ${meta.color}40` : 'none',
          }}>
          {meta.icon}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold" style={{ color: meta.color }}>{meta.name}</span>
            {conf > 0 && (
              <span className="text-[10px] font-bold" style={{ color: meta.color }}>{conf}%</span>
            )}
          </div>
          <p className="text-[10px] text-nexus-faint">{meta.role}</p>
          <div className="progress-bar mt-1.5">
            <div className="progress-fill"
              style={{
                width: status === 'idle' ? '0%' : status === 'working' ? '60%' : '100%',
                background: status === 'done' ? '#10b981' : meta.color,
              }}
            />
          </div>
        </div>
        <div className="flex-shrink-0">
          {status === 'idle'    && <span className="text-nexus-faint text-xs">—</span>}
          {status === 'working' && <span className="text-yellow-400 text-xs animate-pulse">⚡</span>}
          {status === 'done'    && <span className="text-green-400 text-xs">✅</span>}
        </div>
      </div>
    </div>
  )
}

function PhaseIndicator({ current, total = 8 }) {
  if (!current) return null
  const color = PHASE_COLORS[current] || '#a78bfa'
  return (
    <div className="flex items-center gap-2">
      {Array.from({ length: total }, (_, i) => (
        <div key={i}
          className="flex-1 h-1 rounded-full transition-all duration-500"
          style={{ background: i < current ? color : '#1e1e3f' }}
        />
      ))}
    </div>
  )
}

export default function AICorePage() {
  const {
    user, keys, config, serverContext,
    pipelineRunning, pipelineOutput, pipelineFinal, pipelineFiles,
    pipelinePhase, pipelinePhaseNum,
    setPipelineRunning, setPipelinePhase, addPipelineOutput,
    setPipelineFinal, clearPipeline, setAgentStatus, setServerContext,
    sessions, setSessions, currentTask, setCurrentTask,
  } = useStore()

  const [task, setTask] = useState('')
  const [framework, setFramework] = useState('QBCore')
  const [activeTab, setActiveTab] = useState('live')
  const [keysOk, setKeysOk] = useState(false)
  const termRef = useRef(null)

  useEffect(() => {
    const hasKey = Object.values(keys).some(v => v?.trim())
    setKeysOk(hasKey)
  }, [keys])

  // Auto-scroll terminal
  useEffect(() => {
    if (termRef.current) termRef.current.scrollTop = termRef.current.scrollHeight
  }, [pipelineOutput])

  // Wire pipeline events
  useEffect(() => {
    if (!window.nexus) return
    window.nexus.pipeline.removeAllListeners()

    window.nexus.pipeline.onOutput(msg => {
      const { agent, text, phase, phase_num, done, files, final } = msg

      if (phase) {
        setPipelinePhase(phase, phase_num || 0)
        return
      }

      if (done) {
        setPipelineRunning(false)
        setPipelineFinal(final || '', files || {})
        setActiveTab('final')
        // Save session
        if (user) {
          const sessionData = {
            task: currentTask || task,
            framework,
            files: Object.keys(files || {}),
            output: pipelineOutput.map(o => `[${o.agent}] ${o.text}`).join('\n'),
            tokens: 0,
            status: 'complete',
            created: new Date().toISOString(),
          }
          window.nexus.sessions.save(user.id, sessionData).then(() => {
            window.nexus.sessions.load(user.id).then(s => setSessions(s || []))
          })
        }
        return
      }

      if (agent) {
        addPipelineOutput({ agent, text, time: Date.now() })
        // Update agent status
        const isDone    = /✅|done|complete|validated|passed|applied/i.test(text)
        const isWorking = !isDone
        const conf = text.length > 500 ? 90 : text.length > 200 ? 75 : 50
        setAgentStatus(agent, isDone ? 'done' : isWorking ? 'working' : 'idle', conf)
      }
    })

    window.nexus.pipeline.onExit(() => {
      setPipelineRunning(false)
    })

    return () => window.nexus.pipeline.removeAllListeners()
  }, [user, task, framework])

  const handleRun = async () => {
    if (!task.trim()) return
    if (!keysOk) {
      useStore.getState().setPage('settings')
      return
    }

    clearPipeline()
    setCurrentTask(task)
    setPipelineRunning(true)
    setActiveTab('live')

    // Scan server first
    if (config.resourcesPath) {
      const items = await window.nexus.files.list(config.resourcesPath)
      if (items.ok) {
        const ctx = {
          framework,
          resources: items.items.filter(i => i.isDir).map(i => i.name).slice(0, 20),
          resource_count: items.items.filter(i => i.isDir).length,
          has_sql: false,
        }
        setServerContext(ctx)
        useStore.setState({ serverContext: ctx })
      }
    }

    await window.nexus.pipeline.run({
      task: task.trim(),
      keys,
      config,
      context: useStore.getState().serverContext,
    })
  }

  const handleCancel = () => {
    window.nexus.pipeline.cancel()
    setPipelineRunning(false)
  }

  const handleSaveLibrary = async () => {
    if (!user || !pipelineFinal) return
    const entry = {
      task: currentTask || task,
      framework,
      files: Object.keys(pipelineFiles),
      output: pipelineFinal,
      created: new Date().toISOString(),
    }
    await window.nexus.library.save(user.id, entry)
    const lib = await window.nexus.library.load(user.id)
    useStore.getState().setLibrary(lib || [])
  }

  const agentColors = {
    claude: '#a78bfa', gpt: '#34d399', grok: '#38bdf8',
    gemini: '#fbbf24', perp: '#2dd4bf', nexus_ai: '#f472b6',
    nexus: '#7c3aed', system: '#22d3ee', sys: '#22d3ee',
    error: '#f43f5e', console: '#94a3b8',
  }

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex-shrink-0 px-6 py-4 border-b border-nexus-border bg-nexus-card/50 backdrop-blur-xl">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-nexus-text flex items-center gap-2">
              🧠 Nexus AI Core
            </h1>
            <p className="text-xs text-nexus-faint mt-0.5">8-phase multi-agent pipeline</p>
          </div>
          <div className="flex items-center gap-3">
            {!keysOk && (
              <div className="badge badge-red">⚠️ No API Keys</div>
            )}
            <div className="text-xs text-nexus-faint">
              Framework:
              <select
                value={framework}
                onChange={e => setFramework(e.target.value)}
                className="ml-2 bg-nexus-card2 border border-nexus-border rounded-lg px-2 py-1 text-xs text-nexus-text"
              >
                {FRAMEWORKS.map(f => <option key={f} value={f}>{f}</option>)}
              </select>
            </div>
          </div>
        </div>

        {/* Phase bar */}
        {pipelineRunning && (
          <div className="mt-3">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-xs text-nexus-muted">{pipelinePhase || 'Starting...'}</span>
              <span className="text-xs text-nexus-faint">Phase {pipelinePhaseNum || 0}/8</span>
            </div>
            <PhaseIndicator current={pipelinePhaseNum} />
          </div>
        )}
      </div>

      {/* Body */}
      <div className="flex-1 flex overflow-hidden">

        {/* Left panel */}
        <div className="w-72 flex-shrink-0 flex flex-col border-r border-nexus-border p-4 gap-4 overflow-y-auto scrollable">

          {/* Task input */}
          <div className="glass-card p-4">
            <label className="text-xs font-semibold text-nexus-faint uppercase tracking-wider mb-2 block">Your Task</label>
            <textarea
              value={task}
              onChange={e => setTask(e.target.value)}
              placeholder="Describe what to build e.g. Build a /garage command with NUI vehicle menu using QBCore"
              rows={5}
              className="input-field resize-none text-sm leading-relaxed"
              style={{ userSelect: 'text' }}
              onKeyDown={e => { if (e.key === 'Enter' && e.ctrlKey) handleRun() }}
            />
            <p className="text-[10px] text-nexus-faint mt-1">Ctrl+Enter to run</p>
          </div>

          {/* Buttons */}
          <div className="space-y-2">
            <motion.button
              whileHover={{ scale: 1.01 }}
              whileTap={{ scale: 0.99 }}
              onClick={pipelineRunning ? handleCancel : handleRun}
              className={`w-full py-3.5 rounded-xl text-sm font-bold flex items-center justify-center gap-2 ${
                pipelineRunning
                  ? 'bg-red-500/20 border border-red-500/40 text-red-400 hover:bg-red-500/30'
                  : 'btn-primary text-white'
              }`}
            >
              {pipelineRunning ? (
                <><div className="w-4 h-4 border-2 border-red-400/50 border-t-red-400 rounded-full animate-spin" />Cancel Pipeline</>
              ) : (
                <>🚀 Run Pipeline</>
              )}
            </motion.button>

            <button
              onClick={() => { clearPipeline(); setTask('') }}
              className="w-full py-2.5 rounded-xl text-xs font-medium text-nexus-faint btn-ghost"
            >
              🗑️ Clear
            </button>
          </div>

          {/* Key status */}
          <div className="glass-card p-3">
            <p className="text-[10px] font-semibold text-nexus-faint uppercase tracking-wider mb-2">API Status</p>
            <div className="space-y-1.5">
              {['claude','openai','grok','gemini','perplexity'].map(k => {
                const has = !!keys[k]?.trim()
                const labels = { claude:'Claude', openai:'GPT-4o', grok:'Grok', gemini:'Gemini', perplexity:'Perplexity' }
                const colors = { claude:'#a78bfa', openai:'#34d399', grok:'#38bdf8', gemini:'#fbbf24', perplexity:'#2dd4bf' }
                return (
                  <div key={k} className="flex items-center justify-between text-[11px]">
                    <span style={{ color: has ? colors[k] : '#475569' }}>{labels[k]}</span>
                    <span className={has ? 'text-green-400' : 'text-nexus-faint'}>{has ? '✅' : '—'}</span>
                  </div>
                )
              })}
            </div>
          </div>

          {/* Agents */}
          <div>
            <p className="text-[10px] font-semibold text-nexus-faint uppercase tracking-wider mb-2">Agent Status</p>
            <div className="space-y-2">
              {Object.keys(AGENT_META).map(k => <AgentCard key={k} agentKey={k} />)}
            </div>
          </div>
        </div>

        {/* Right panel */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Tabs */}
          <div className="flex-shrink-0 flex items-center gap-1 px-4 pt-3 border-b border-nexus-border">
            {[
              { id: 'live',  label: '📡 Live Output' },
              { id: 'final', label: '✅ Final Output' },
              { id: 'files', label: `📄 Files (${Object.keys(pipelineFiles).length})` },
            ].map(({ id, label }) => (
              <button
                key={id}
                onClick={() => setActiveTab(id)}
                className={`px-4 py-2 text-xs font-semibold rounded-t-lg border-b-2 transition-all ${
                  activeTab === id
                    ? 'text-nexus-purple border-nexus-accent bg-nexus-card2/50'
                    : 'text-nexus-faint border-transparent hover:text-nexus-muted'
                }`}
              >
                {label}
              </button>
            ))}

            <div className="ml-auto flex gap-2 pb-1">
              {pipelineFinal && (
                <>
                  <button
                    onClick={() => { navigator.clipboard.writeText(pipelineFinal) }}
                    className="px-3 py-1.5 rounded-lg text-xs btn-ghost text-nexus-muted"
                  >📋 Copy</button>
                  {user && (
                    <button
                      onClick={handleSaveLibrary}
                      className="px-3 py-1.5 rounded-lg text-xs btn-primary text-white"
                    >📚 Save to Library</button>
                  )}
                </>
              )}
            </div>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-hidden">
            <AnimatePresence mode="wait">
              {activeTab === 'live' && (
                <motion.div key="live" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="h-full p-4">
                  <div
                    ref={termRef}
                    className="terminal h-full p-4 overflow-y-auto scrollable"
                  >
                    {pipelineOutput.length === 0 ? (
                      <div className="flex flex-col items-center justify-center h-full text-nexus-faint">
                        <p className="text-4xl mb-4">⬡</p>
                        <p className="text-sm">Pipeline output will appear here</p>
                        <p className="text-xs mt-1">Type a task and click Run Pipeline</p>
                      </div>
                    ) : (
                      pipelineOutput.map((msg, i) => {
                        const color = agentColors[msg.agent] || '#94a3b8'
                        return (
                          <div key={i} className="mb-0.5">
                            <span className="opacity-50 text-[10px]">[{msg.agent?.toUpperCase()?.padEnd(10)}]</span>
                            <span style={{ color }}> {msg.text}</span>
                          </div>
                        )
                      })
                    )}
                    {pipelineRunning && (
                      <div className="flex items-center gap-2 mt-2">
                        <div className="w-2 h-2 rounded-full bg-purple-400 animate-pulse" />
                        <span className="text-purple-400 text-xs">Pipeline running...</span>
                      </div>
                    )}
                  </div>
                </motion.div>
              )}

              {activeTab === 'final' && (
                <motion.div key="final" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="h-full p-4">
                  <div className="terminal h-full p-4 overflow-y-auto scrollable whitespace-pre-wrap text-nexus-text text-xs">
                    {pipelineFinal || (
                      <div className="flex flex-col items-center justify-center h-full text-nexus-faint">
                        <p className="text-4xl mb-4">✅</p>
                        <p className="text-sm">Final output appears here when build completes</p>
                      </div>
                    )}
                  </div>
                </motion.div>
              )}

              {activeTab === 'files' && (
                <motion.div key="files" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="h-full p-4 overflow-y-auto scrollable">
                  {Object.keys(pipelineFiles).length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full text-nexus-faint">
                      <p className="text-4xl mb-4">📄</p>
                      <p className="text-sm">Generated files appear here</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {Object.entries(pipelineFiles).map(([name, content]) => (
                        <div key={name} className="glass-card p-4">
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center gap-2">
                              <span className="text-sm">📄</span>
                              <span className="text-sm font-semibold text-nexus-text">{name}</span>
                              <span className="text-[10px] text-nexus-faint">{content.length} chars</span>
                            </div>
                            <button
                              onClick={() => navigator.clipboard.writeText(content)}
                              className="text-xs btn-ghost px-2 py-1 rounded-lg text-nexus-faint"
                            >
                              📋 Copy
                            </button>
                          </div>
                          <pre className="terminal p-3 text-xs overflow-x-auto max-h-48 text-green-300">
                            {content.slice(0, 500)}{content.length > 500 ? '\n... (truncated)' : ''}
                          </pre>
                        </div>
                      ))}
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  )
}
