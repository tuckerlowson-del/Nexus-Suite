export { WebToolsPage as default } from './OtherPages'
