// ── LibraryPage ───────────────────────────────────────
import React, { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useStore } from '../store'

export function LibraryPage() {
  const { user, library, setLibrary, setPage, setCurrentTask } = useStore()
  const [search, setSearch] = useState('')
  const [deleting, setDeleting] = useState(null)

  useEffect(() => {
    if (user) {
      window.nexus.library.load(user.id).then(lib => setLibrary(lib || []))
    }
  }, [user])

  const filtered = library.filter(e =>
    !search || e.task?.toLowerCase().includes(search.toLowerCase())
  )

  const handleDelete = async (id) => {
    if (!user) return
    await window.nexus.library.delete(user.id, id)
    const lib = await window.nexus.library.load(user.id)
    setLibrary(lib || [])
    setDeleting(null)
  }

  const handleRebuild = (entry) => {
    setCurrentTask(entry.task || '')
    setPage('ai')
  }

  return (
    <div className="h-full flex flex-col">
      <div className="flex-shrink-0 px-6 py-4 border-b border-nexus-border bg-nexus-card/50">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-nexus-text">📚 Resource Library</h1>
            <p className="text-xs text-nexus-faint mt-0.5">{library.length} saved scripts</p>
          </div>
          <div className="flex items-center gap-3">
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search scripts..."
              className="input-field w-56 text-sm py-2"
              style={{ userSelect: 'text' }}
            />
            <button onClick={() => setPage('ai')}
              className="btn-primary px-4 py-2 rounded-xl text-xs font-semibold text-white">
              + New Build
            </button>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto scrollable p-6">
        {!user ? (
          <div className="flex flex-col items-center justify-center h-full text-nexus-faint">
            <p className="text-5xl mb-4">🔒</p>
            <p className="text-sm font-medium">Sign in to save scripts</p>
            <p className="text-xs mt-1">Your library is tied to your Google account</p>
            <button onClick={() => useStore.getState().logout()}
              className="mt-4 btn-primary px-4 py-2 rounded-xl text-xs font-semibold text-white">
              Sign In
            </button>
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-nexus-faint">
            <p className="text-5xl mb-4">📚</p>
            <p className="text-sm font-medium">{search ? 'No results' : 'Library is empty'}</p>
            <p className="text-xs mt-1">{search ? 'Try a different search' : 'Build something in AI Core to save it here'}</p>
            {!search && (
              <button onClick={() => setPage('ai')}
                className="mt-4 btn-primary px-4 py-2 rounded-xl text-xs font-semibold text-white">
                Start Building
              </button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-4">
            <AnimatePresence>
              {filtered.map((entry, i) => (
                <motion.div
                  key={entry.id || i}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ delay: i * 0.04 }}
                  className="glass-card p-5 group"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <div className="w-9 h-9 rounded-xl bg-purple-500/20 border border-purple-500/30 flex items-center justify-center text-lg">🔨</div>
                      <div>
                        <p className="text-sm font-semibold text-nexus-text line-clamp-1">{entry.task || 'Build'}</p>
                        <p className="text-xs text-nexus-faint">{entry.framework || 'QBCore'} • {new Date(entry.created).toLocaleDateString()}</p>
                      </div>
                    </div>
                    <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button onClick={() => handleRebuild(entry)}
                        className="p-1.5 rounded-lg btn-ghost text-nexus-faint hover:text-nexus-purple text-xs">
                        🔄
                      </button>
                      <button onClick={() => setDeleting(entry.id)}
                        className="p-1.5 rounded-lg btn-ghost text-nexus-faint hover:text-red-400 text-xs">
                        🗑️
                      </button>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-1.5 mb-3">
                    {(entry.files || []).map(f => (
                      <span key={f} className="px-2 py-0.5 rounded-md bg-nexus-card3 border border-nexus-border text-[10px] text-nexus-faint">
                        📄 {f}
                      </span>
                    ))}
                  </div>

                  {deleting === entry.id && (
                    <div className="flex items-center gap-2 mt-3 p-3 rounded-lg bg-red-500/10 border border-red-500/20">
                      <p className="text-xs text-red-300 flex-1">Delete this script?</p>
                      <button onClick={() => handleDelete(entry.id)}
                        className="px-3 py-1 rounded-lg bg-red-500/30 text-red-300 text-xs font-semibold hover:bg-red-500/50">
                        Delete
                      </button>
                      <button onClick={() => setDeleting(null)}
                        className="px-3 py-1 rounded-lg btn-ghost text-nexus-faint text-xs">
                        Cancel
                      </button>
                    </div>
                  )}
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}
      </div>
    </div>
  )
}

// ── HistoryPage ───────────────────────────────────────
export function HistoryPage() {
  const { user, sessions, setSessions } = useStore()
  const [search, setSearch] = useState('')

  useEffect(() => {
    if (user) {
      window.nexus.sessions.load(user.id).then(s => setSessions(s || []))
    }
  }, [user])

  const filtered = sessions.filter(s =>
    !search || s.task?.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div className="h-full flex flex-col">
      <div className="flex-shrink-0 px-6 py-4 border-b border-nexus-border bg-nexus-card/50">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-nexus-text">🕐 History</h1>
            <p className="text-xs text-nexus-faint mt-0.5">{sessions.length} past sessions</p>
          </div>
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search history..."
            className="input-field w-56 text-sm py-2"
            style={{ userSelect: 'text' }}
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto scrollable p-6">
        {!user ? (
          <div className="flex flex-col items-center justify-center h-full text-nexus-faint">
            <p className="text-5xl mb-4">🔒</p>
            <p className="text-sm font-medium">Sign in to view history</p>
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-nexus-faint">
            <p className="text-5xl mb-4">🕐</p>
            <p className="text-sm font-medium">{search ? 'No results' : 'No history yet'}</p>
          </div>
        ) : (
          <div className="space-y-3">
            {filtered.map((s, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.03 }}
                className="glass-card p-4 hover:border-nexus-border2 transition-all"
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-xl bg-nexus-card3 flex items-center justify-center text-xl flex-shrink-0">🔨</div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-nexus-text truncate">{s.task || 'Build Session'}</p>
                    <div className="flex items-center gap-3 mt-1">
                      <span className="text-xs text-nexus-faint">{s.framework || 'QBCore'}</span>
                      <span className="text-xs text-nexus-faint">•</span>
                      <span className="text-xs text-nexus-faint">{s.files?.length || 0} files</span>
                      <span className="text-xs text-nexus-faint">•</span>
                      <span className="text-xs text-nexus-faint">{new Date(s.created).toLocaleString()}</span>
                    </div>
                  </div>
                  <div className={`badge ${s.status === 'complete' ? 'badge-green' : 'badge-purple'} text-[10px]`}>
                    {s.status || 'complete'}
                  </div>
                </div>
                {s.files?.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 mt-3">
                    {s.files.map(f => (
                      <span key={f} className="px-2 py-0.5 rounded-md bg-nexus-card3 border border-nexus-border text-[10px] text-nexus-faint">
                        📄 {f}
                      </span>
                    ))}
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

// ── WebToolsPage ──────────────────────────────────────
export function WebToolsPage() {
  const [activeTab, setActiveTab] = useState('replit')

  const tools = [
    { id: 'replit',  name: 'Replit',     url: 'https://replit.com',    color: '#fb923c', icon: '🟠', desc: 'Code and deploy in the browser' },
    { id: 'lovable', name: 'Lovable.ai', url: 'https://lovable.dev',   color: '#e879f9', icon: '💜', desc: 'AI that builds full-stack apps' },
    { id: 'rocket',  name: 'Rocket.new', url: 'https://rocket.new',    color: '#60a5fa', icon: '🚀', desc: 'Ship full-stack apps with AI' },
  ]

  const tool = tools.find(t => t.id === activeTab)

  return (
    <div className="h-full flex flex-col">
      <div className="flex-shrink-0 px-6 py-4 border-b border-nexus-border bg-nexus-card/50">
        <h1 className="text-xl font-bold text-nexus-text">🌐 Web Tools</h1>
        <p className="text-xs text-nexus-faint mt-0.5">External AI coding platforms</p>
      </div>

      <div className="flex border-b border-nexus-border px-6">
        {tools.map(t => (
          <button key={t.id} onClick={() => setActiveTab(t.id)}
            className={`px-5 py-3 text-sm font-medium border-b-2 transition-all ${
              activeTab === t.id
                ? 'border-current'
                : 'border-transparent text-nexus-faint hover:text-nexus-muted'
            }`}
            style={{ color: activeTab === t.id ? t.color : undefined }}>
            {t.icon} {t.name}
          </button>
        ))}
      </div>

      <div className="flex-1 flex flex-col items-center justify-center p-8">
        {tool && (
          <motion.div
            key={tool.id}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center max-w-md"
          >
            <div className="w-24 h-24 mx-auto rounded-3xl flex items-center justify-center text-5xl mb-6 shadow-2xl"
              style={{ background: `${tool.color}20`, border: `2px solid ${tool.color}40` }}>
              {tool.icon}
            </div>
            <h2 className="text-2xl font-bold mb-2" style={{ color: tool.color }}>{tool.name}</h2>
            <p className="text-nexus-muted mb-2">{tool.desc}</p>
            <p className="text-xs text-nexus-faint mb-8">{tool.url}</p>

            <div className="glass-card p-4 mb-6 text-left">
              <p className="text-xs font-semibold text-nexus-faint uppercase tracking-wider mb-2">Why can't it be embedded?</p>
              <p className="text-xs text-nexus-muted leading-relaxed">
                {tool.name} blocks iframe embedding for security reasons — same as banking sites and Google. 
                The Open in Browser button gives you the full experience instantly.
              </p>
            </div>

            <motion.button
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              onClick={() => window.nexus.shell.openUrl(tool.url)}
              className="px-8 py-4 rounded-2xl text-white font-bold text-sm shadow-xl"
              style={{ background: `linear-gradient(135deg, ${tool.color}, ${tool.color}cc)` }}
            >
              🚀 Open {tool.name} in Browser
            </motion.button>
          </motion.div>
        )}
      </div>
    </div>
  )
}

// ── SettingsPage ──────────────────────────────────────
export function SettingsPage() {
  const { user, keys, config, setKeys, setConfig } = useStore()
  const [localKeys,   setLocalKeys]   = useState({ ...keys })
  const [localConfig, setLocalConfig] = useState({ ...config })
  const [saved,       setSaved]       = useState(false)
  const [testing,     setTesting]     = useState(false)
  const [testResults, setTestResults] = useState({})
  const [showKeys,    setShowKeys]    = useState({})

  useEffect(() => { setLocalKeys({ ...keys }) }, [keys])
  useEffect(() => { setLocalConfig({ ...config }) }, [config])

  const handleSave = async () => {
    setKeys(localKeys)
    setConfig(localConfig)
    if (user) {
      await window.nexus.keys.save(user.id, localKeys)
      await window.nexus.config.save(user.id, localConfig)
    }
    setSaved(true)
    setTimeout(() => setSaved(false), 2500)
  }

  const browseFile = async (key) => {
    const p = await window.nexus.dialog.openFile()
    if (p) setLocalConfig(c => ({ ...c, [key]: p }))
  }

  const browseDir = async (key) => {
    const p = await window.nexus.dialog.openDir()
    if (p) setLocalConfig(c => ({ ...c, [key]: p }))
  }

  const testKeys = async () => {
    setTesting(true)
    setTestResults({})
    const results = {}
    for (const [key, val] of Object.entries(localKeys)) {
      if (!val?.trim()) { results[key] = 'skip'; continue }
      results[key] = 'testing'
      setTestResults({ ...results })
      await new Promise(r => setTimeout(r, 300))
      results[key] = val.length > 20 ? 'ok' : 'invalid'
      setTestResults({ ...results })
    }
    setTesting(false)
  }

  const KEY_META = [
    { key: 'claude',     label: 'Claude (Anthropic)', color: '#a78bfa', url: 'console.anthropic.com',    role: 'Planner, Reviewer, Security' },
    { key: 'openai',     label: 'GPT-4o (OpenAI)',    color: '#34d399', url: 'platform.openai.com',      role: 'Lead Coder, Debugger'        },
    { key: 'grok',       label: 'Grok (xAI)',         color: '#38bdf8', url: 'console.x.ai',             role: 'Bug Hunter'                  },
    { key: 'gemini',     label: 'Gemini (Google)',     color: '#fbbf24', url: 'aistudio.google.com',      role: 'UI/NUI Designer'             },
    { key: 'perplexity', label: 'Perplexity',         color: '#2dd4bf', url: 'perplexity.ai/settings/api', role: 'QA Tester'                },
  ]

  const PATH_META = [
    { key: 'fxserverExe',   label: 'FXServer.exe',      hint: 'Full path to FXServer.exe',                   isFile: true },
    { key: 'serverData',    label: 'Server Data Folder', hint: 'Folder containing server.cfg',               isFile: false },
    { key: 'resourcesPath', label: 'Resources Folder',   hint: 'Your resources directory',                   isFile: false },
  ]

  const statusIcon = (key) => {
    const r = testResults[key]
    if (r === 'testing') return <div className="w-3 h-3 border border-yellow-400/50 border-t-yellow-400 rounded-full animate-spin" />
    if (r === 'ok')      return <span className="text-green-400 text-xs">✅</span>
    if (r === 'invalid') return <span className="text-red-400 text-xs">❌</span>
    if (r === 'skip')    return <span className="text-nexus-faint text-xs">—</span>
    return null
  }

  return (
    <div className="h-full flex flex-col">
      <div className="flex-shrink-0 px-6 py-4 border-b border-nexus-border bg-nexus-card/50">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-nexus-text">⚙️ Settings</h1>
            <p className="text-xs text-nexus-faint mt-0.5">API keys and server configuration</p>
          </div>
          <div className="flex gap-3">
            <button onClick={testKeys} disabled={testing}
              className="btn-ghost px-4 py-2 rounded-xl text-xs font-semibold text-nexus-muted hover:text-nexus-text disabled:opacity-50">
              {testing ? '🔌 Testing...' : '🔌 Test All Keys'}
            </button>
            <motion.button
              whileHover={{ scale: 1.01 }}
              whileTap={{ scale: 0.99 }}
              onClick={handleSave}
              className={`px-5 py-2 rounded-xl text-xs font-bold transition-all ${
                saved ? 'bg-green-500/20 text-green-400 border border-green-500/30' : 'btn-primary text-white'
              }`}>
              {saved ? '✅ Saved!' : '💾 Save Settings'}
            </motion.button>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto scrollable p-6 space-y-6">
        {/* Profile */}
        {user && (
          <div className="glass-card p-5">
            <p className="text-xs font-semibold text-nexus-faint uppercase tracking-wider mb-4">Profile</p>
            <div className="flex items-center gap-4">
              <img src={user.avatar} alt={user.name}
                className="w-14 h-14 rounded-2xl ring-2 ring-purple-500/30"
                onError={e => { e.target.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name)}&background=7c3aed&color=fff` }}
              />
              <div>
                <p className="font-semibold text-nexus-text">{user.name}</p>
                <p className="text-sm text-nexus-muted">{user.email}</p>
                <p className="text-xs text-nexus-faint mt-0.5">Google Account</p>
              </div>
              <div className="ml-auto">
                <div className="badge badge-green">✅ Signed In</div>
              </div>
            </div>
          </div>
        )}

        {/* Server info */}
        <div className="glass-card p-5">
          <p className="text-xs font-semibold text-nexus-faint uppercase tracking-wider mb-4">Server Info</p>
          <div className="grid grid-cols-2 gap-4">
            {[
              { key: 'serverName', label: 'Server Name', placeholder: 'My FiveM Server' },
              { key: 'serverPort', label: 'Server Port', placeholder: '30120' },
            ].map(({ key, label, placeholder }) => (
              <div key={key}>
                <label className="text-xs font-medium text-nexus-faint mb-1.5 block">{label}</label>
                <input
                  value={localConfig[key] || ''}
                  onChange={e => setLocalConfig(c => ({ ...c, [key]: e.target.value }))}
                  placeholder={placeholder}
                  className="input-field text-sm"
                  style={{ userSelect: 'text' }}
                />
              </div>
            ))}
          </div>
        </div>

        {/* API Keys */}
        <div className="glass-card p-5">
          <div className="flex items-center justify-between mb-4">
            <p className="text-xs font-semibold text-nexus-faint uppercase tracking-wider">API Keys</p>
            <p className="text-xs text-nexus-faint">Minimum: Claude + GPT-4o</p>
          </div>
          <div className="space-y-3">
            {KEY_META.map(({ key, label, color, url, role }) => (
              <div key={key} className="p-4 rounded-xl bg-nexus-card3 border border-nexus-border">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full" style={{ background: color }} />
                    <span className="text-sm font-semibold" style={{ color }}>{label}</span>
                    <span className="text-xs text-nexus-faint">— {role}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    {statusIcon(key)}
                    <button onClick={() => window.nexus.shell.openUrl(`https://${url}`)}
                      className="text-xs text-nexus-faint hover:text-nexus-muted transition-colors">
                      Get key ↗
                    </button>
                  </div>
                </div>
                <div className="relative">
                  <input
                    type={showKeys[key] ? 'text' : 'password'}
                    value={localKeys[key] || ''}
                    onChange={e => setLocalKeys(k => ({ ...k, [key]: e.target.value }))}
                    placeholder="Paste API key here..."
                    className="input-field text-sm pr-10"
                    style={{ userSelect: 'text' }}
                  />
                  <button
                    onClick={() => setShowKeys(s => ({ ...s, [key]: !s[key] }))}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-nexus-faint hover:text-nexus-muted text-xs"
                  >
                    {showKeys[key] ? '🙈' : '👁️'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Server paths */}
        <div className="glass-card p-5">
          <p className="text-xs font-semibold text-nexus-faint uppercase tracking-wider mb-4">Server Paths</p>
          <div className="space-y-3">
            {PATH_META.map(({ key, label, hint, isFile }) => (
              <div key={key}>
                <label className="text-xs font-medium text-nexus-faint mb-1.5 block">{label}</label>
                <p className="text-[10px] text-nexus-faint mb-1.5">{hint}</p>
                <div className="flex gap-2">
                  <input
                    value={localConfig[key] || ''}
                    onChange={e => setLocalConfig(c => ({ ...c, [key]: e.target.value }))}
                    placeholder={`Enter ${label.toLowerCase()}...`}
                    className="input-field text-sm flex-1"
                    style={{ userSelect: 'text' }}
                  />
                  <button
                    onClick={() => isFile ? browseFile(key) : browseDir(key)}
                    className="px-4 py-2 rounded-xl btn-ghost text-xs font-medium text-nexus-muted hover:text-nexus-text flex-shrink-0"
                  >
                    Browse
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Danger zone */}
        {user && (
          <div className="glass-card p-5 border-red-500/20">
            <p className="text-xs font-semibold text-red-400 uppercase tracking-wider mb-4">Danger Zone</p>
            <button
              onClick={() => { useStore.getState().logout(); localStorage.removeItem('nexus_user') }}
              className="px-4 py-2.5 rounded-xl bg-red-500/10 border border-red-500/25 text-red-400 text-sm font-semibold hover:bg-red-500/20 transition-all"
            >
              🚪 Sign Out of Nexus Suite
            </button>
          </div>
        )}
      </div>
    </div>
  )
}

export default LibraryPage
