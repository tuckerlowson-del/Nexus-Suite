import React, { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { useStore } from '../store'

const STAT_CARDS = [
  { key: 'builds',  label: 'Total Builds',   icon: '🔨', color: '#a78bfa' },
  { key: 'tokens',  label: 'Tokens Used',    icon: '⚡', color: '#22d3ee' },
  { key: 'scripts', label: 'Scripts Saved',  icon: '📚', color: '#34d399' },
  { key: 'sessions',label: 'Sessions',       icon: '🕐', color: '#fbbf24' },
]

function AgentDot({ color, label, active }) {
  return (
    <div className="flex flex-col items-center gap-1">
      <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xs font-bold"
        style={{
          background: `${color}20`,
          border: `1px solid ${color}40`,
          color,
          boxShadow: active ? `0 0 12px ${color}40` : 'none',
        }}>
        {label}
      </div>
    </div>
  )
}

export default function DashboardPage() {
  const { user, isGuest, setPage, sessions, library, serverOnline, config, setServerOnline } = useStore()
  const [stats, setStats] = useState({ builds: 0, tokens: 0, scripts: 0, sessions: 0 })

  useEffect(() => {
    if (user) {
      // Load sessions and library
      const loadData = async () => {
        const sess = await window.nexus.sessions.load(user.id)
        const lib  = await window.nexus.library.load(user.id)
        useStore.getState().setSessions(sess || [])
        useStore.getState().setLibrary(lib || [])

        const totalTokens = (sess || []).reduce((sum, s) => sum + (s.tokens || 0), 0)
        setStats({
          builds:   (sess || []).length,
          tokens:   totalTokens,
          scripts:  (lib  || []).length,
          sessions: (sess || []).length,
        })
      }
      loadData()
    }
  }, [user])

  const recentSessions = sessions.slice(0, 5)

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      {/* Welcome header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-nexus-text">
            {user ? `Welcome back, ${user.name.split(' ')[0]} 👋` : 'Welcome, Guest 👋'}
          </h1>
          <p className="text-nexus-muted mt-1 text-sm">
            {user ? 'Your FiveM AI dev platform is ready.' : 'Sign in to save your sessions and scripts.'}
          </p>
        </div>
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => setPage('ai')}
          className="btn-primary px-6 py-3 rounded-xl text-sm font-semibold text-white flex items-center gap-2"
        >
          🚀 Start Building
        </motion.button>
      </div>

      {/* Guest banner */}
      {isGuest && (
        <motion.div
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-4 rounded-xl bg-yellow-500/10 border border-yellow-500/30 flex items-center justify-between"
        >
          <div className="flex items-center gap-3">
            <span className="text-2xl">⚠️</span>
            <div>
              <p className="text-sm font-semibold text-yellow-300">You're in Guest Mode</p>
              <p className="text-xs text-yellow-400/70">Your builds and scripts won't be saved. Sign in to keep everything.</p>
            </div>
          </div>
          <button
            onClick={() => useStore.getState().logout()}
            className="px-4 py-2 rounded-lg bg-yellow-500/20 border border-yellow-500/40 text-yellow-300 text-xs font-semibold hover:bg-yellow-500/30 transition-all"
          >
            Sign In
          </button>
        </motion.div>
      )}

      {/* Stats */}
      {user && (
        <div className="grid grid-cols-4 gap-4">
          {STAT_CARDS.map(({ key, label, icon, color }, i) => (
            <motion.div
              key={key}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="stat-card"
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-2xl">{icon}</span>
                <span className="text-xs font-semibold px-2 py-1 rounded-full"
                  style={{ background: `${color}20`, color, border: `1px solid ${color}30` }}>
                  {key === 'tokens' ? (stats[key] > 1000 ? `${(stats[key]/1000).toFixed(1)}k` : stats[key]) : stats[key]}
                </span>
              </div>
              <p className="text-lg font-bold text-nexus-text">
                {key === 'tokens' ? (stats[key] > 1000 ? `${(stats[key]/1000).toFixed(1)}k` : stats[key]) : stats[key]}
              </p>
              <p className="text-xs text-nexus-faint mt-0.5">{label}</p>
            </motion.div>
          ))}
        </div>
      )}

      {/* Main grid */}
      <div className="grid grid-cols-3 gap-6">
        {/* Server status */}
        <div className="glass-card p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-nexus-text">Server Status</h3>
            <div className={`flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full ${
              serverOnline ? 'bg-green-500/15 text-green-400 border border-green-500/25' : 'bg-red-500/15 text-red-400 border border-red-500/25'
            }`}>
              <span className={`w-1.5 h-1.5 rounded-full ${serverOnline ? 'bg-green-400 animate-pulse' : 'bg-red-400'}`}/>
              {serverOnline ? 'Online' : 'Offline'}
            </div>
          </div>

          <p className="text-xs text-nexus-faint mb-4 truncate">
            {config.serverName || 'My FiveM Server'}
          </p>

          <div className="space-y-2">
            <button onClick={() => setPage('server')}
              className="w-full btn-ghost py-2.5 rounded-lg text-xs font-medium text-nexus-muted hover:text-nexus-text text-center">
              🖥️ Open Server Panel
            </button>
          </div>
        </div>

        {/* AI Agents */}
        <div className="glass-card p-5">
          <h3 className="text-sm font-semibold text-nexus-text mb-4">AI Agents Ready</h3>
          <div className="grid grid-cols-3 gap-2 mb-4">
            {[
              { color: '#a78bfa', label: 'Claude', short: 'C' },
              { color: '#34d399', label: 'GPT-4o', short: 'G' },
              { color: '#38bdf8', label: 'Grok',   short: 'X' },
              { color: '#fbbf24', label: 'Gemini', short: 'Ge' },
              { color: '#2dd4bf', label: 'Perplx', short: 'P' },
              { color: '#f472b6', label: 'Nexus',  short: 'N' },
            ].map(({ color, label, short }) => (
              <div key={label} className="flex flex-col items-center gap-1">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xs font-bold"
                  style={{ background: `${color}20`, border: `1px solid ${color}40`, color }}>
                  {short}
                </div>
                <span className="text-[9px] text-nexus-faint">{label}</span>
              </div>
            ))}
          </div>
          <button onClick={() => setPage('ai')}
            className="w-full btn-primary py-2.5 rounded-lg text-xs font-semibold text-white text-center">
            🧠 Launch AI Core
          </button>
        </div>

        {/* Quick actions */}
        <div className="glass-card p-5">
          <h3 className="text-sm font-semibold text-nexus-text mb-4">Quick Actions</h3>
          <div className="space-y-2">
            {[
              { icon: '🧠', label: 'New Build',    page: 'ai',      color: '#a78bfa' },
              { icon: '📁', label: 'File Manager', page: 'files',   color: '#fbbf24' },
              { icon: '📚', label: 'Library',      page: 'library', color: '#2dd4bf' },
              { icon: '🌐', label: 'Web Tools',    page: 'webtools',color: '#f472b6' },
            ].map(({ icon, label, page: p, color }) => (
              <button key={p} onClick={() => setPage(p)}
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg btn-ghost text-sm font-medium text-nexus-muted hover:text-nexus-text">
                <span className="text-base">{icon}</span>
                <span>{label}</span>
                <svg className="ml-auto w-4 h-4 opacity-40" viewBox="0 0 16 16" fill="currentColor">
                  <path d="M6 3l5 5-5 5"/>
                </svg>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Recent sessions */}
      {user && (
        <div className="glass-card p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-nexus-text">Recent Sessions</h3>
            <button onClick={() => setPage('history')}
              className="text-xs text-nexus-purple hover:text-purple-300 transition-colors">
              View all →
            </button>
          </div>

          {recentSessions.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-3xl mb-3">🔨</p>
              <p className="text-nexus-muted text-sm">No builds yet</p>
              <p className="text-nexus-faint text-xs mt-1">Your build history will appear here</p>
              <button onClick={() => setPage('ai')}
                className="mt-4 btn-primary px-4 py-2 rounded-lg text-xs font-semibold text-white">
                Start First Build
              </button>
            </div>
          ) : (
            <div className="space-y-2">
              {recentSessions.map((s, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className="flex items-center gap-3 p-3 rounded-lg bg-nexus-card2/60 border border-nexus-border/50 hover:border-nexus-border transition-all"
                >
                  <div className="w-8 h-8 rounded-lg bg-purple-500/20 flex items-center justify-center text-sm">🔨</div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-nexus-text truncate">{s.task || 'Build Session'}</p>
                    <p className="text-xs text-nexus-faint">{s.framework || 'QBCore'} • {s.files?.length || 0} files • {s.created ? new Date(s.created).toLocaleDateString() : ''}</p>
                  </div>
                  <div className={`badge ${s.status === 'complete' ? 'badge-green' : 'badge-purple'} text-[10px]`}>
                    {s.status || 'complete'}
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
