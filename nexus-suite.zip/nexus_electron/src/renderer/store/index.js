import { create } from 'zustand'

export const useStore = create((set, get) => ({
  // ── Auth ─────────────────────────────────────────────
  user:    null,
  isGuest: false,
  setUser: (user) => set({ user, isGuest: false }),
  setGuest: () => set({ user: null, isGuest: true }),
  logout: () => set({ user: null, isGuest: false }),

  // ── Navigation ────────────────────────────────────────
  page: 'dashboard',
  setPage: (page) => set({ page }),

  // ── API Keys ──────────────────────────────────────────
  keys: {},
  setKeys: (keys) => set({ keys }),

  // ── Server Config ─────────────────────────────────────
  config: {
    serverName:    'My FiveM Server',
    serverPort:    '30120',
    fxserverExe:   '',
    serverData:    '',
    resourcesPath: '',
  },
  setConfig: (config) => set({ config }),
  updateConfig: (patch) => set(s => ({ config: { ...s.config, ...patch } })),

  // ── Server Status ─────────────────────────────────────
  serverOnline:  false,
  serverOutput:  [],
  setServerOnline: (v) => set({ serverOnline: v }),
  addServerOutput: (line) => set(s => ({
    serverOutput: [...s.serverOutput.slice(-500), line]
  })),
  clearServerOutput: () => set({ serverOutput: [] }),

  // ── Pipeline ──────────────────────────────────────────
  pipelineRunning:  false,
  pipelinePhase:    '',
  pipelinePhaseNum: 0,
  pipelineOutput:   [],
  pipelineFinal:    '',
  pipelineFiles:    {},
  agentStatus: {
    claude:    'idle',
    gpt:       'idle',
    grok:      'idle',
    gemini:    'idle',
    perp:      'idle',
    nexus_ai:  'idle',
  },
  agentConf: {
    claude: 0, gpt: 0, grok: 0, gemini: 0, perp: 0, nexus_ai: 0,
  },

  setPipelineRunning: (v) => set({ pipelineRunning: v }),
  setPipelinePhase:   (phase, num) => set({ pipelinePhase: phase, pipelinePhaseNum: num }),
  addPipelineOutput:  (msg) => set(s => ({
    pipelineOutput: [...s.pipelineOutput.slice(-1000), msg]
  })),
  setPipelineFinal:   (text, files) => set({ pipelineFinal: text, pipelineFiles: files }),
  clearPipeline: () => set({
    pipelineOutput: [], pipelineFinal: '', pipelineFiles: {},
    pipelinePhase: '', pipelinePhaseNum: 0,
    agentStatus: { claude:'idle', gpt:'idle', grok:'idle', gemini:'idle', perp:'idle', nexus_ai:'idle' },
    agentConf: { claude:0, gpt:0, grok:0, gemini:0, perp:0, nexus_ai:0 },
  }),
  setAgentStatus: (agent, status, conf) => set(s => ({
    agentStatus: { ...s.agentStatus, [agent]: status },
    agentConf:   { ...s.agentConf, [agent]: conf || s.agentConf[agent] },
  })),

  // ── Server Context ────────────────────────────────────
  serverContext: { framework: 'QBCore', resources: [], resource_count: 0, has_sql: false },
  setServerContext: (ctx) => set({ serverContext: ctx }),

  // ── Sessions ──────────────────────────────────────────
  sessions: [],
  setSessions: (sessions) => set({ sessions }),

  // ── Library ───────────────────────────────────────────
  library: [],
  setLibrary: (library) => set({ library }),

  // ── Current task ─────────────────────────────────────
  currentTask: '',
  setCurrentTask: (t) => set({ currentTask: t }),
}))
