@echo off
title NEXUS SUITE — Build EXE
color 0B

echo.
echo  ==========================================
echo   NEXUS SUITE — Building EXE
echo  ==========================================
echo.

python --version >nul 2>&1
IF %ERRORLEVEL% NEQ 0 ( set PYTHON=python3 ) ELSE ( set PYTHON=python )

echo Building EXE — this takes 2-3 minutes...
echo.

%PYTHON% -m PyInstaller --onefile --windowed --name "NEXUS_SUITE" main.py

IF %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERROR] Build failed. Run install_and_build.bat first.
    pause
    exit /b 1
)

echo.
echo  ==========================================
echo   BUILD COMPLETE!
echo   Your EXE is here: dist\NEXUS_SUITE.exe
echo   Double-click it to run without CMD.
echo  ==========================================
echo.
pause
