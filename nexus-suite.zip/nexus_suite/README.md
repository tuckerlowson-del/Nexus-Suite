# ⬡ NEXUS SUITE — FiveM AI Dev Platform

Free alternative to **Ovan AI** ($60/mo) + **HTN Panel** ($6/mo)  
Combined into one single EXE.

---

## 🚀 Quick Start (3 steps)

### Step 1 — Install Python
Download Python 3.11+ from https://python.org/downloads  
⚠️ CHECK "Add Python to PATH" during install

### Step 2 — Run the installer
Double-click `install_and_build.bat`  
It installs everything and builds the EXE automatically.

### Step 3 — Set up API keys
Open the app → Go to **⚙️ Setup** → Paste your API keys → Save

---

## 🔑 API Keys Needed

| AI | Get Key From | Required? |
|---|---|---|
| Claude | console.anthropic.com | ✅ Yes |
| GPT-4o | platform.openai.com | ✅ Yes |
| Grok | console.x.ai | Optional |
| Gemini | aistudio.google.com | Optional |
| Perplexity | perplexity.ai/settings/api | Optional |

Minimum: Claude + GPT-4o to run the full pipeline.

---

## 🧠 What's Inside

### Nexus AI Core (Ovan Clone + Multi-Agent Pipeline merged)
- 8-phase AI pipeline
- Phase 1: Server Scan (Claude)
- Phase 2: Planning (Claude)
- Phase 3: Code Writing (GPT-4o + Claude + Ovan)
- Phase 4: Debugging (Grok + Claude + GPT-4o)
- Phase 5: UI/NUI Building (Claude + Gemini + GPT-4o + Ovan)
- Phase 6: QA Testing (Perplexity + Claude + Gemini)
- Phase 7: Security Audit (Claude)
- Phase 8: Deploy + Self-Fix Loop

### Nexus Panel (HTN Panel Clone)
- Server start/stop/restart
- server.cfg editor
- Backup system
- Resource manager

### Other Features
- Live console with ⚡ Quick Fix buttons
- File manager with inline editor + AI fix
- Resource library (saves every built script)
- Confidence scoring per AI
- Security audit before deploy
- Change logs per resource (NEXUS_CHANGELOG.md)

---

## 💰 Cost Comparison

| | Paid Route | Nexus Suite |
|---|---|---|
| Ovan AI | $60/mo | FREE |
| HTN Panel | $6/mo | FREE |
| API usage | - | ~$5-20/mo |
| **Total** | **$66/mo** | **~$5-20/mo** |

---

## 📁 Files

```
nexus_suite/
├── main.py                 ← Full source code
├── requirements.txt        ← Python dependencies
├── install_and_build.bat   ← One-click setup
├── README.md               ← This file
├── nexus_keys.json         ← API keys (auto-created)
├── nexus_config.json       ← Paths config (auto-created)
├── nexus_library.json      ← Saved resources (auto-created)
└── dist/
    └── NEXUS_SUITE.exe     ← Built EXE (after build)
```
